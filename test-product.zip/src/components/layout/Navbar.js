import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { FaSearch, FaShoppingCart, FaHeart, FaUser, FaSignOutAlt, FaCog, FaBars, FaTimes } from 'react-icons/fa';

/**
 * Modern, mobile‑first Navbar using Tailwind CSS
 * - New color theme
 * - No reuse of previous classnames
 * - Responsive with an animated mobile drawer
 */
const Navbar = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const { totalItems } = useCart();
  const { products: wishlistItems } = useWishlist();
  const navigate = useNavigate();
  const location = useLocation();
  const userMenuRef = useRef(null);

  // Close menus when route changes
  useEffect(() => {
    setIsMenuOpen(false);
    setIsUserMenuOpen(false);
  }, [location]);

  // Close user dropdown on outside click / Escape
  useEffect(() => {
    const onClick = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setIsUserMenuOpen(false);
      }
    };
    const onKey = (e) => {
      if (e.key === 'Escape') {
        setIsUserMenuOpen(false);
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/?search=${encodeURIComponent(searchTerm.trim())}`);
      setIsMenuOpen(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const Counter = ({ count }) => (
    count > 0 ? (
      <span className="ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-white/90 px-1 text-[10px] font-bold text-indigo-700">
        {count}
      </span>
    ) : null
  );

  return (
    <header className="sticky top-0 z-50 w-full bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 text-white shadow">
      <nav className="mx-auto max-w-7xl px-3 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Left: Brand & mobile toggle */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 backdrop-blur transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/60 lg:hidden"
              onClick={() => setIsMenuOpen((s) => !s)}
              aria-label="Toggle menu"
              aria-expanded={isMenuOpen}
            >
              {isMenuOpen ? <FaTimes /> : <FaBars />}
            </button>

            <Link to="/" className="group inline-flex items-center gap-2">
              <div className="grid h-9 w-9 place-items-center rounded-xl bg-white text-indigo-700 font-extrabold shadow-sm">
                E
              </div>
              <span className="text-lg font-extrabold tracking-tight drop-shadow-sm">
                E‑Shop
              </span>
            </Link>
          </div>

          {/* Center: Search (desktop) */}
          <form onSubmit={handleSearch} className="hidden md:block md:w-full md:max-w-xl">
            <div className="relative">
              <FaSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-white/70" />
              <input
                type="text"
                placeholder="Search products…"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full rounded-2xl border-0 bg-white/15 py-2.5 pl-10 pr-28 text-sm text-white placeholder-white/70 shadow-inner outline-none ring-1 ring-white/20 backdrop-blur transition focus:ring-2 focus:ring-white/60"
              />
              <button
                type="submit"
                className="absolute right-1 top-1/2 -translate-y-1/2 rounded-xl bg-white/90 px-4 py-2 text-sm font-semibold text-indigo-700 shadow hover:bg-white"
              >
                Search
              </button>
            </div>
          </form>

          {/* Right: Actions */}
          <div className="flex items-center gap-1 sm:gap-2">
            <Link
              to="/wishlist"
              className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-sm font-medium backdrop-blur transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/60"
            >
              <FaHeart />
              <span className="hidden sm:inline">Wishlist</span>
              <Counter count={wishlistItems.length} />
            </Link>

            <Link
              to="/cart"
              className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-sm font-medium backdrop-blur transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/60"
            >
              <FaShoppingCart />
              <span className="hidden sm:inline">Cart</span>
              <Counter count={totalItems} />
            </Link>

            {/* User */}
            {isAuthenticated ? (
              <div className="relative" ref={userMenuRef}>
                <button
                  className="inline-flex items-center gap-2 rounded-full bg-white/10 p-1.5 pr-3 text-sm font-medium backdrop-blur transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/60"
                  onClick={() => setIsUserMenuOpen((s) => !s)}
                  aria-haspopup="menu"
                  aria-expanded={isUserMenuOpen}
                >
                  <div className="grid h-8 w-8 place-items-center rounded-full bg-white text-indigo-700"><FaUser /></div>
                  <span className="hidden sm:inline max-w-[10rem] truncate">{user?.name}</span>
                </button>

                {isUserMenuOpen && (
                  <div
                    role="menu"
                    className="absolute right-0 mt-2 w-56 overflow-hidden rounded-2xl border border-white/20 bg-white/95 p-1.5 text-slate-800 shadow-xl backdrop-blur"
                  >
                    <Link to="/profile" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100">
                      <FaUser /> Profile
                    </Link>
                    <Link to="/orders" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100">
                      <FaShoppingCart /> Orders
                    </Link>
                    {user?.role === 'admin' && (
                      <Link to="/admin" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100">
                        <FaCog /> Admin Panel
                      </Link>
                    )}
                    <button onClick={handleLogout} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100">
                      <FaSignOutAlt /> Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="hidden items-center gap-2 md:flex">
                <Link
                  to="/login"
                  className="rounded-xl bg-white/90 px-4 py-2 text-sm font-semibold text-indigo-700 shadow transition hover:bg-white"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="rounded-xl border border-white/60 px-4 py-2 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/10"
                >
                  Register
                </Link>
              </div>
            )}

            {/* Mobile search button (also opens menu) */}
            <button
              className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 backdrop-blur transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/60 md:hidden"
              onClick={() => setIsMenuOpen(true)}
              aria-label="Open search"
            >
              <FaSearch />
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {isMenuOpen && (
          <div className="origin-top animate-in fade-in-0 zoom-in-95">
            <div className="mt-3 rounded-2xl border border-white/25 bg-white/95 p-3 text-slate-800 shadow-2xl backdrop-blur md:hidden">
              <form onSubmit={handleSearch} className="mb-3">
                <div className="relative">
                  <FaSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search products…"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full rounded-2xl border border-slate-200 bg-white py-2.5 pl-10 pr-24 text-sm text-slate-800 shadow-sm outline-none transition focus:border-indigo-300 focus:ring-4 focus:ring-indigo-500/20"
                  />
                  <button
                    type="submit"
                    className="absolute right-1 top-1/2 -translate-y-1/2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow hover:bg-indigo-700"
                  >
                    Search
                  </button>
                </div>
              </form>

              <div className="grid gap-1">
                <Link to="/wishlist" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium hover:bg-slate-100">
                  <FaHeart /> Wishlist ({wishlistItems.length})
                </Link>
                <Link to="/cart" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium hover:bg-slate-100">
                  <FaShoppingCart /> Cart ({totalItems})
                </Link>

                {isAuthenticated ? (
                  <>
                    <Link to="/profile" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium hover:bg-slate-100">
                      <FaUser /> Profile
                    </Link>
                    <Link to="/orders" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium hover:bg-slate-100">
                      <FaShoppingCart /> Orders
                    </Link>
                    {user?.role === 'admin' && (
                      <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium hover:bg-slate-100">
                        <FaCog /> Admin Panel
                      </Link>
                    )}
                    <button onClick={handleLogout} className="flex items-center gap-2 rounded-xl px-3 py-2 text-left text-sm font-medium hover:bg-slate-100">
                      <FaSignOutAlt /> Logout
                    </button>
                  </>
                ) : (
                  <>
                    <Link to="/login" onClick={() => setIsMenuOpen(false)} className="flex items-center justify-center rounded-xl bg-indigo-600 px-3 py-2 text-sm font-semibold text-white hover:bg-indigo-700">
                      Login
                    </Link>
                    <Link to="/register" onClick={() => setIsMenuOpen(false)} className="flex items-center justify-center rounded-xl border border-slate-300 px-3 py-2 text-sm font-semibold hover:bg-slate-50">
                      Register
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Navbar;
