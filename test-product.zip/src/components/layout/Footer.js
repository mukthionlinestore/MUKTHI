import React from 'react';
import { Link } from 'react-router-dom';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaEnvelope, FaPhone, FaMapMarkerAlt } from 'react-icons/fa';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-slate-200 bg-white text-slate-700">
      <div className="mx-auto  px-4 sm:px-6 lg:px-8">
        {/* Top */}
        <div className="grid grid-cols-1 gap-10 py-12 sm:grid-cols-2 lg:grid-cols-6">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link to="/" className="inline-flex items-center gap-2">
              <div className="grid h-9 w-9 place-items-center rounded-xl bg-indigo-600 text-white font-bold">E</div>
              <span className="text-lg font-extrabold tracking-tight text-slate-900">E‑Shop</span>
            </Link>
            <p className="mt-3 max-w-sm text-sm leading-6 text-slate-600">
              Your one‑stop destination for all your shopping needs. Quality products, competitive prices, and excellent service.
            </p>
            <div className="mt-4 flex items-center gap-3">
              <a href="#" aria-label="Facebook" className="social">
                <FaFacebook />
              </a>
              <a href="#" aria-label="Twitter" className="social">
                <FaTwitter />
              </a>
              <a href="#" aria-label="Instagram" className="social">
                <FaInstagram />
              </a>
              <a href="#" aria-label="LinkedIn" className="social">
                <FaLinkedin />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="footer-title">Quick Links</h4>
            <ul className="footer-list">
              <li><Link className="footer-link" to="/">Home</Link></li>
              <li><Link className="footer-link" to="/products">Products</Link></li>
              <li><Link className="footer-link" to="/about">About Us</Link></li>
              <li><Link className="footer-link" to="/contact">Contact</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="footer-title">Categories</h4>
            <ul className="footer-list">
              <li><Link className="footer-link" to="/?category=Electronics">Electronics</Link></li>
              <li><Link className="footer-link" to="/?category=Clothing">Clothing</Link></li>
              <li><Link className="footer-link" to="/?category=Home">Home & Garden</Link></li>
              <li><Link className="footer-link" to="/?category=Sports">Sports</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="footer-title">Customer Service</h4>
            <ul className="footer-list">
              <li><Link className="footer-link" to="/help">Help Center</Link></li>
              <li><Link className="footer-link" to="/shipping">Shipping Info</Link></li>
              <li><Link className="footer-link" to="/returns">Returns</Link></li>
              <li><Link className="footer-link" to="/privacy">Privacy Policy</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="footer-title">Contact Info</h4>
            <ul className="mt-3 space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <FaMapMarkerAlt className="mt-0.5 text-slate-500" />
                <span>123 Shopping St, City, Country</span>
              </li>
              <li className="flex items-center gap-3">
                <FaPhone className="text-slate-500" />
                <a className="hover:text-slate-900" href="tel:+15551234567">+1 (555) 123‑4567</a>
              </li>
              <li className="flex items-center gap-3">
                <FaEnvelope className="text-slate-500" />
                <a className="hover:text-slate-900" href="mailto:info@eshop.com">info@eshop.com</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-slate-200 py-5">
          <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
            <p className="text-sm text-slate-600">&copy; {year} E‑Shop. All rights reserved.</p>
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <Link className="footer-link" to="/terms">Terms of Service</Link>
              <Link className="footer-link" to="/privacy">Privacy Policy</Link>
              <Link className="footer-link" to="/cookies">Cookie Policy</Link>
            </div>
          </div>
        </div>
      </div>

      {/* Tailwind component utilities for concise reuse */}
      <style>{`
        .footer-title { @apply text-sm font-semibold text-slate-900; }
        .footer-list { @apply mt-3 space-y-2 text-sm; }
        .footer-link { @apply text-slate-600 hover:text-slate-900 hover:underline underline-offset-4; }
        .social { @apply inline-flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-600 hover:bg-slate-50; }
      `}</style>
    </footer>
  );
};

export default Footer;
