import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaShoppingCart, FaHeart, FaStar } from 'react-icons/fa';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { toast } from 'react-toastify';
import SizeColorModal from './SizeColorModal';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const [showSizeColorModal, setShowSizeColorModal] = useState(false);

  // Safely get the product image
  const getProductImage = () => {
    if (!product.images || !Array.isArray(product.images) || product.images.length === 0) {
      return 'https://via.placeholder.com/400x400?text=No+Image';
    }
    
    const thumbnailIndex = product.thumbnailIndex || 0;
    const imageIndex = Math.min(thumbnailIndex, product.images.length - 1);
    return product.images[imageIndex];
  };

  const handleAddToCart = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (product.quantity <= 0) {
      toast.error('Product is out of stock');
      return;
    }

    // Check if product has colors or sizes that need selection
    const hasColors = product.colors && product.colors.length > 0;
    const hasSizes = product.sizes && product.sizes.length > 0;
    
    if (hasColors || hasSizes) {
      setShowSizeColorModal(true);
      return;
    }

    await addToCart(product, 1);
  };

  const handleWishlistToggle = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isInWishlist(product._id)) {
      await removeFromWishlist(product._id);
    } else {
      await addToWishlist(product);
    }
  };

  const handleModalConfirm = async ({ product, quantity, selectedColor, selectedSize }) => {
    await addToCart(product, quantity, selectedColor, selectedSize);
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FaStar
          key={i}
          className={i <= rating ? 'star filled' : 'star'}
          style={{
            fontSize: '14px',
            color: i <= rating ? '#fbbf24' : '#d1d5db',
            marginRight: '2px'
          }}
        />
      );
    }
    return stars;
  };

  // Calculate discount percentage
  const discountPercentage = product.originalPrice && product.originalPrice > product.price
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null;

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      background: '#ffffff',
      borderRadius: '16px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
      transition: 'all 0.3s ease',
      overflow: 'hidden',
      position: 'relative',
      border: '1px solid #f1f3f4',
      height: '100%'
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.transform = 'translateY(-4px)';
      e.currentTarget.style.boxShadow = '0 12px 32px rgba(0, 0, 0, 0.1)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.04)';
    }}>
      
      <div style={{
        position: 'relative',
        aspectRatio: '1',
        overflow: 'hidden',
        background: '#f8f9fa',
        borderRadius: '16px 16px 0 0'
      }}>
        <img
          src={getProductImage()}
          alt={product.name || 'Product'}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            transition: 'transform 0.4s ease'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.05)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
          }}
          onError={(e) => {
            e.currentTarget.src = 'https://via.placeholder.com/400x400?text=No+Image';
          }}
        />
        
        {/* Badges */}
        <div style={{
          position: 'absolute',
          top: '12px',
          left: '12px',
          display: 'flex',
          flexDirection: 'column',
          gap: '6px',
          zIndex: 2
        }}>
          {product.isNewProduct && (
            <span style={{
              padding: '4px 8px',
              borderRadius: '6px',
              fontSize: '11px',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white'
            }}>New</span>
          )}
          {discountPercentage && (
            <span style={{
              padding: '4px 8px',
              borderRadius: '6px',
              fontSize: '11px',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              background: 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)',
              color: 'white'
            }}>-{discountPercentage}%</span>
          )}
          {product.isSold && (
            <span style={{
              padding: '4px 8px',
              borderRadius: '6px',
              fontSize: '11px',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              background: 'linear-gradient(135deg, #95a5a6 0%, #7f8c8d 100%)',
              color: 'white'
            }}>Sold</span>
          )}
          {product.quantity <= 10 && product.quantity > 0 && (
            <span style={{
              padding: '4px 8px',
              borderRadius: '6px',
              fontSize: '11px',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              background: 'linear-gradient(135deg, #f39c12 0%, #e67e22 100%)',
              color: 'white'
            }}>Low Stock</span>
          )}
          {product.quantity <= 0 && (
            <span style={{
              padding: '4px 8px',
              borderRadius: '6px',
              fontSize: '11px',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
              background: 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)',
              color: 'white'
            }}>Out of Stock</span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={handleWishlistToggle}
          style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            background: 'rgba(255, 255, 255, 0.9)',
            border: 'none',
            borderRadius: '50%',
            width: '36px',
            height: '36px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            zIndex: 2,
            backdropFilter: 'blur(4px)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.1)';
            e.currentTarget.style.background = 'rgba(255, 255, 255, 1)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
            e.currentTarget.style.background = 'rgba(255, 255, 255, 0.9)';
          }}
        >
          <FaHeart
            style={{
              color: isInWishlist(product._id) ? '#e74c3c' : '#6b7280',
              fontSize: '16px',
              transition: 'color 0.2s ease'
            }}
          />
        </button>
      </div>

      {/* Product Info */}
      <div style={{
        padding: '16px',
        flex: 1,
        display: 'flex',
        flexDirection: 'column'
      }}>
        <Link
          to={`/product/${product._id}`}
          style={{
            textDecoration: 'none',
            color: 'inherit',
            flex: 1,
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          <h3 style={{
            fontSize: '16px',
            fontWeight: '600',
            color: '#1f2937',
            margin: '0 0 8px 0',
            lineHeight: '1.4',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
            textOverflow: 'ellipsis'
          }}>
            {product.name}
          </h3>

          <p style={{
            fontSize: '14px',
            color: '#6b7280',
            margin: '0 0 12px 0',
            lineHeight: '1.4',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            flex: 1
          }}>
            {product.description}
          </p>

          {/* Rating */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            marginBottom: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', marginRight: '8px' }}>
              {renderStars(product.rating || 0)}
            </div>
            <span style={{
              fontSize: '14px',
              color: '#6b7280'
            }}>
              ({product.numReviews || 0})
            </span>
          </div>

          {/* Price */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            marginBottom: '16px'
          }}>
            <span style={{
              fontSize: '18px',
              fontWeight: '700',
              color: '#1f2937'
            }}>
              ${product.price?.toFixed(2)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span style={{
                fontSize: '14px',
                color: '#6b7280',
                textDecoration: 'line-through'
              }}>
                ${product.originalPrice.toFixed(2)}
              </span>
            )}
          </div>
        </Link>

        {/* Add to Cart Button */}
        <button
          onClick={handleAddToCart}
          disabled={product.quantity <= 0}
          style={{
            width: '100%',
            padding: '12px 16px',
            background: product.quantity <= 0 
              ? '#e5e7eb' 
              : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: product.quantity <= 0 ? '#9ca3af' : 'white',
            border: 'none',
            borderRadius: '12px',
            fontSize: '14px',
            fontWeight: '600',
            cursor: product.quantity <= 0 ? 'not-allowed' : 'pointer',
            transition: 'all 0.2s ease',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px'
          }}
          onMouseEnter={(e) => {
            if (product.quantity > 0) {
              e.currentTarget.style.transform = 'translateY(-1px)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.3)';
            }
          }}
          onMouseLeave={(e) => {
            if (product.quantity > 0) {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }
          }}
        >
          <FaShoppingCart style={{ fontSize: '14px' }} />
          {product.quantity <= 0 ? 'Out of Stock' : 'Add to Cart'}
        </button>
      </div>

      {/* Size/Color Selection Modal */}
      {showSizeColorModal && (
        <SizeColorModal
          product={product}
          isOpen={showSizeColorModal}
          onClose={() => setShowSizeColorModal(false)}
          onConfirm={handleModalConfirm}
        />
      )}
    </div>
  );
};

export default ProductCard;