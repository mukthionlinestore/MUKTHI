import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../config/axios';
import { useAuth } from '../context/AuthContext';
import { 
  FaEye, 
  FaTruck, 
  FaBox, 
  FaCheckCircle, 
  FaTimes, 
  FaClock, 
  FaUndo,
  FaMapMarkerAlt,
  FaPhone,
  FaEnvelope,
  FaCreditCard,
  FaMoneyBillWave,
  FaCalendarAlt,
  FaShoppingCart,
  FaDollarSign,
  FaPrint,
  FaDownload,
  FaStar,
  FaArrowLeft,
  FaExclamationTriangle
} from 'react-icons/fa';
import { toast } from 'react-toastify';

const UserOrders = () => {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [filters, setFilters] = useState({
    status: '',
    dateFrom: '',
    dateTo: ''
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login?redirect=/orders');
      return;
    }
    fetchOrders();
  }, [isAuthenticated, navigate, filters]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams(filters);
      const response = await axios.get(`/api/orders?${params}`);
      setOrders(response.data.orders || []);
    } catch (error) {
      toast.error('Failed to load orders');
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending': return 'warning';
      case 'processing': return 'info';
      case 'shipped': return 'primary';
      case 'delivered': return 'success';
      case 'cancelled': return 'danger';
      case 'returned': return 'secondary';
      default: return 'light';
    }
  };

  const getStatusIcon = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending': return <FaClock />;
      case 'processing': return <FaBox />;
      case 'shipped': return <FaTruck />;
      case 'delivered': return <FaCheckCircle />;
      case 'cancelled': return <FaTimes />;
      case 'returned': return <FaUndo />;
      default: return <FaClock />;
    }
  };

  const getStatusDescription = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending': return 'Your order has been placed and is awaiting confirmation';
      case 'processing': return 'Your order is being prepared for shipment';
      case 'shipped': return 'Your order has been shipped and is on its way';
      case 'delivered': return 'Your order has been delivered successfully';
      case 'cancelled': return 'Your order has been cancelled';
      case 'returned': return 'Your order has been returned';
      default: return 'Order status unknown';
    }
  };

  const handleCancelOrder = async (orderId) => {
    if (!window.confirm('Are you sure you want to cancel this order? This action cannot be undone.')) {
      return;
    }

    try {
      await axios.post(`/api/orders/${orderId}/cancel`);
      toast.success('Order cancelled successfully');
      fetchOrders();
    } catch (error) {
      toast.error('Failed to cancel order');
      console.error('Error cancelling order:', error);
    }
  };

  const handleReturnRequest = async (orderId, returnReason) => {
    try {
      await axios.post(`/api/orders/${orderId}/return`, { returnReason });
      toast.success('Return request submitted successfully');
      fetchOrders();
    } catch (error) {
      toast.error('Failed to submit return request');
      console.error('Error submitting return request:', error);
    }
  };

  const printOrder = (order) => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Order #${order.orderNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; }
            .order-info { margin-bottom: 20px; }
            .items { margin-bottom: 20px; }
            .item { border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; }
            .total { font-weight: bold; font-size: 18px; }
            .status { color: #007bff; font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Order Receipt</h1>
            <h2>Order #${order.orderNumber}</h2>
            <p>Date: ${new Date(order.createdAt).toLocaleDateString()}</p>
          </div>
          
          <div class="order-info">
            <h3>Customer Information</h3>
            <p><strong>Name:</strong> ${order.user?.name}</p>
            <p><strong>Email:</strong> ${order.user?.email}</p>
            <p><strong>Phone:</strong> ${order.shippingAddress?.phone}</p>
            
            <h3>Shipping Address</h3>
            <p>${order.shippingAddress?.fullName}</p>
            <p>${order.shippingAddress?.street}</p>
            <p>${order.shippingAddress?.city}, ${order.shippingAddress?.state} ${order.shippingAddress?.zipCode}</p>
            <p>${order.shippingAddress?.country}</p>
            
            <h3>Order Status</h3>
            <p class="status">${order.status}</p>
            ${order.trackingNumber ? `<p><strong>Tracking Number:</strong> ${order.trackingNumber}</p>` : ''}
          </div>
          
          <div class="items">
            <h3>Order Items</h3>
            ${order.items.map(item => `
              <div class="item">
                <p><strong>${item.product?.name}</strong></p>
                <p>Quantity: ${item.quantity}</p>
                <p>Price: $${item.price?.toFixed(2)} each</p>
                <p>Total: $${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            `).join('')}
          </div>
          
          <div class="total">
            <p>Subtotal: $${order.subtotal?.toFixed(2)}</p>
            <p>Shipping: ${order.shippingCost === 0 ? 'Free' : `$${order.shippingCost?.toFixed(2)}`}</p>
            <p>Tax: $${order.tax?.toFixed(2)}</p>
            <p>Total: $${order.total?.toFixed(2)}</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  if (!isAuthenticated) {
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Loading your orders...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <button 
              onClick={() => navigate('/profile')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-800"
            >
              <FaArrowLeft /> Back to Profile
            </button>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">My Orders</h1>
          <p className="text-gray-600">Track your order status and view order history</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Orders</option>
                <option value="Pending">Pending</option>
                <option value="Processing">Processing</option>
                <option value="Shipped">Shipped</option>
                <option value="Delivered">Delivered</option>
                <option value="Cancelled">Cancelled</option>
                <option value="Returned">Returned</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date From</label>
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) => setFilters(prev => ({ ...prev, dateFrom: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date To</label>
              <input
                type="date"
                value={filters.dateTo}
                onChange={(e) => setFilters(prev => ({ ...prev, dateTo: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Orders List */}
        <div className="space-y-6">
          {orders.length > 0 ? (
            orders.map((order) => (
              <div key={order._id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-4">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Order #{order.orderNumber}
                        </h3>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium status-${getStatusColor(order.status)}`}>
                          {getStatusIcon(order.status)}
                          {order.status}
                        </span>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${order.isPaid ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                          {order.isPaid ? <FaCheckCircle className="inline mr-1" /> : <FaExclamationTriangle className="inline mr-1" />}
                          {order.isPaid ? 'Paid' : 'Unpaid'}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                        <div>
                          <span className="font-medium">Order Date:</span>
                          <p>{new Date(order.createdAt).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <span className="font-medium">Total Amount:</span>
                          <p className="text-lg font-semibold text-gray-900">${order.total?.toFixed(2)}</p>
                        </div>
                        <div>
                          <span className="font-medium">Items:</span>
                          <p>{order.items?.length || 0} item(s)</p>
                        </div>
                      </div>

                      <div className="mt-4">
                        <p className="text-sm text-gray-600">
                          {getStatusDescription(order.status)}
                        </p>
                        {order.trackingNumber && (
                          <p className="text-sm text-blue-600 mt-1">
                            <strong>Tracking Number:</strong> {order.trackingNumber}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-col gap-2">
                      <button
                        onClick={() => {
                          setSelectedOrder(order);
                          setShowOrderModal(true);
                        }}
                        className="btn btn-outline btn-sm"
                      >
                        <FaEye /> View Details
                      </button>
                      
                      <button
                        onClick={() => printOrder(order)}
                        className="btn btn-outline btn-sm"
                      >
                        <FaPrint /> Print Receipt
                      </button>

                      {order.status === 'Pending' && (
                        <button
                          onClick={() => handleCancelOrder(order._id)}
                          className="btn btn-danger btn-sm"
                        >
                          <FaTimes /> Cancel Order
                        </button>
                      )}

                      {order.status === 'Delivered' && (
                        <button
                          onClick={() => {
                            const reason = prompt('Please provide a reason for return:');
                            if (reason) {
                              handleReturnRequest(order._id, reason);
                            }
                          }}
                          className="btn btn-warning btn-sm"
                        >
                          <FaUndo /> Request Return
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-12 text-center">
              <FaShoppingCart className="text-6xl text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Orders Yet</h3>
              <p className="text-gray-600 mb-6">You haven't placed any orders yet. Start shopping to see your orders here!</p>
              <button
                onClick={() => navigate('/products')}
                className="btn btn-primary"
              >
                Start Shopping
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Order Details Modal */}
      {showOrderModal && selectedOrder && (
        <OrderDetailsModal
          order={selectedOrder}
          onClose={() => {
            setShowOrderModal(false);
            setSelectedOrder(null);
          }}
          onCancel={handleCancelOrder}
          onReturn={handleReturnRequest}
          onPrint={printOrder}
        />
      )}
    </div>
  );
};

// Order Details Modal Component
const OrderDetailsModal = ({ order, onClose, onCancel, onReturn, onPrint }) => {
  const [showReturnForm, setShowReturnForm] = useState(false);
  const [returnReason, setReturnReason] = useState('');

  const handleReturnSubmit = () => {
    if (returnReason.trim()) {
      onReturn(order._id, returnReason);
      setShowReturnForm(false);
      setReturnReason('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">
              Order Details - #{order.orderNumber}
            </h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl">
              ×
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Order Information */}
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <FaShoppingCart /> Order Information
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className={`font-medium status-${order.status?.toLowerCase()}`}>
                      {order.status}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Order Date:</span>
                    <span>{new Date(order.createdAt).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment Method:</span>
                    <span>{order.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment Status:</span>
                    <span className={order.isPaid ? 'text-green-600' : 'text-yellow-600'}>
                      {order.isPaid ? 'Paid' : 'Unpaid'}
                    </span>
                  </div>
                  {order.trackingNumber && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tracking Number:</span>
                      <span className="text-blue-600">{order.trackingNumber}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <FaMapMarkerAlt /> Shipping Address
                </h3>
                <div className="text-sm text-gray-600">
                  <p>{order.shippingAddress?.fullName}</p>
                  <p>{order.shippingAddress?.street}</p>
                  <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} {order.shippingAddress?.zipCode}</p>
                  <p>{order.shippingAddress?.country}</p>
                  <p className="mt-2">
                    <FaPhone className="inline mr-1" />
                    {order.shippingAddress?.phone}
                  </p>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <FaBox /> Order Items
                </h3>
                <div className="space-y-3">
                  {order.items?.map((item, index) => (
                    <div key={index} className="flex gap-3 p-3 bg-white rounded border">
                      <img 
                        src={item.product?.images?.[0]} 
                        alt={item.product?.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{item.product?.name}</h4>
                        <p className="text-sm text-gray-600">{item.product?.brand}</p>
                        {item.selectedColor && (
                          <p className="text-sm text-gray-600">Color: {item.selectedColor.name}</p>
                        )}
                        {item.selectedSize && (
                          <p className="text-sm text-gray-600">Size: {item.selectedSize}</p>
                        )}
                        <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                        <p className="font-medium">${item.price?.toFixed(2)} each</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <FaDollarSign /> Order Summary
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${order.subtotal?.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping:</span>
                    <span>{order.shippingCost === 0 ? 'Free' : `$${order.shippingCost?.toFixed(2)}`}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax:</span>
                    <span>${order.tax?.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg border-t pt-2">
                    <span>Total:</span>
                    <span>${order.total?.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t">
            <button onClick={onPrint} className="btn btn-outline">
              <FaPrint /> Print Receipt
            </button>
            
            {order.status === 'Pending' && (
              <button onClick={() => onCancel(order._id)} className="btn btn-danger">
                <FaTimes /> Cancel Order
              </button>
            )}

            {order.status === 'Delivered' && !showReturnForm && (
              <button onClick={() => setShowReturnForm(true)} className="btn btn-warning">
                <FaUndo /> Request Return
              </button>
            )}

            {showReturnForm && (
              <div className="w-full">
                <textarea
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  placeholder="Please provide a reason for return..."
                  className="w-full p-3 border border-gray-300 rounded-lg mb-3"
                  rows="3"
                />
                <div className="flex gap-3">
                  <button onClick={handleReturnSubmit} className="btn btn-warning">
                    Submit Return Request
                  </button>
                  <button onClick={() => setShowReturnForm(false)} className="btn btn-outline">
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserOrders;
