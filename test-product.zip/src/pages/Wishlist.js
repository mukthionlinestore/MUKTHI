import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import axios from '../config/axios';
import { useAuth } from '../context/AuthContext';
import { FaShoppingCart, FaTrash, FaArrowLeft, FaTimes, FaRegHeart } from 'react-icons/fa';
import { toast } from 'react-toastify';

// --- Helpers ---
const useAbortableAxios = () => {
  const abortRef = useRef(null);
  useEffect(() => () => abortRef.current?.abort?.(), []);
  const withSignal = () => {
    abortRef.current?.abort?.();
    abortRef.current = new AbortController();
    return { signal: abortRef.current.signal };
  };
  return { withSignal };
};

const Wishlist = () => {
  const { isAuthenticated } = useAuth();
  const [wishlist, setWishlist] = useState(null);
  const [loading, setLoading] = useState(true);
  const [movingToCart, setMovingToCart] = useState({});
  const [removing, setRemoving] = useState({});
  const { withSignal } = useAbortableAxios();

  useEffect(() => {
    const fetchWishlist = async () => {
      if (!isAuthenticated) { setLoading(false); return; }
      try {
        setLoading(true);
        const response = await axios.get('/api/wishlist', withSignal());
        setWishlist(response.data);
      } catch (error) {
        if (error.name !== 'CanceledError') {
          console.error('Error fetching wishlist:', error);
          toast.error('Failed to load wishlist');
        }
      } finally {
        setLoading(false);
      }
    };
    fetchWishlist();
  }, [isAuthenticated]);

  const removeFromWishlist = async (productId) => {
    if (removing[productId]) return; // lock
    if (!window.confirm('Remove this item from your wishlist?')) return;

    setRemoving((p) => ({ ...p, [productId]: true }));
    try {
      const response = await axios.delete(`/api/wishlist/remove/${productId}`);
      setWishlist(response.data);
      toast.success('Item removed');
    } catch (error) {
      console.error('Error removing from wishlist:', error);
      toast.error('Failed to remove item');
    } finally {
      setRemoving((p) => ({ ...p, [productId]: false }));
    }
  };

  const moveToCart = async (productId) => {
    if (movingToCart[productId]) return; // lock
    setMovingToCart((p) => ({ ...p, [productId]: true }));
    try {
      await axios.post('/api/cart/add', { productId, quantity: 1 });
      const response = await axios.delete(`/api/wishlist/remove/${productId}`);
      setWishlist(response.data);
      toast.success('Moved to cart');
    } catch (error) {
      console.error('Error moving to cart:', error);
      if (error.response?.data?.message === 'Product already in wishlist') {
        toast.error('This item is already in your cart');
      } else {
        toast.error('Failed to move item to cart');
      }
    } finally {
      setMovingToCart((p) => ({ ...p, [productId]: false }));
    }
  };

  const clearWishlist = async () => {
    if (!window.confirm('Clear your entire wishlist?')) return;
    try {
      const response = await axios.delete('/api/wishlist/clear');
      setWishlist(response.data);
      toast.success('Wishlist cleared');
    } catch (error) {
      console.error('Error clearing wishlist:', error);
      toast.error('Failed to clear wishlist');
    }
  };

  // --- UI ---
  if (!isAuthenticated) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white dark:bg-neutral-900 shadow-lg rounded-2xl p-8 text-center">
          <FaRegHeart className="mx-auto text-4xl mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Please log in to view your wishlist</h2>
          <p className="text-neutral-500 mb-6">You need to be logged in to see your saved items.</p>
          <Link to="/login" className="inline-flex items-center justify-center rounded-xl px-4 py-2 bg-black text-white hover:opacity-90 transition">Log In</Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-neutral-600">
          <div className="h-10 w-10 border-2 border-neutral-300 border-t-transparent rounded-full animate-spin" />
          <p>Loading your wishlist…</p>
        </div>
      </div>
    );
  }

  if (!wishlist || wishlist.products.length === 0) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="bg-white dark:bg-neutral-900 rounded-2xl shadow-sm p-10 text-center">
          <FaRegHeart className="mx-auto text-4xl mb-3" />
          <h2 className="text-2xl font-semibold mb-2">Your wishlist is empty</h2>
          <p className="text-neutral-500 mb-6">Save items you love by tapping the heart on products.</p>
          <Link to="/" className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition">
            <FaArrowLeft /> Start Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3 mb-6">
        <div>
          <h1 className="text-3xl font-bold">My Wishlist</h1>
          <p className="text-neutral-500">{wishlist.products.length} {wishlist.products.length === 1 ? 'item' : 'items'} saved</p>
        </div>
        <button onClick={clearWishlist} className="inline-flex items-center gap-2 rounded-xl border px-3 py-2 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition">
          <FaTimes /> Clear Wishlist
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {wishlist.products.map((item) => {
          const product = item.product;
          if (!product) {
            return (
              <div key={item._id} className="rounded-2xl border p-6 flex items-center justify-between">
                <p className="text-neutral-600">Product no longer available</p>
                <button onClick={() => removeFromWishlist(item.product)} className="text-red-600 hover:opacity-80">Remove</button>
              </div>
            );
          }
          return (
            <div key={item._id} className="group rounded-2xl border hover:shadow-md transition overflow-hidden bg-white dark:bg-neutral-900">
              <div className="relative aspect-[4/3] overflow-hidden">
                <Link to={`/product/${product._id}`}>
                  <img src={product.images?.[0] || '/placeholder-image.jpg'} alt={product.name} className="h-full w-full object-cover" />
                </Link>
                {product.isNewProduct && (
                  <span className="absolute left-3 top-3 text-xs font-medium bg-black text-white px-2 py-1 rounded-full">New</span>
                )}
                <button
                  onClick={() => removeFromWishlist(product._id)}
                  disabled={removing[product._id]}
                  className="absolute right-3 top-3 inline-flex items-center justify-center h-9 w-9 rounded-full bg-white/90 shadow hover:bg-white transition"
                  title="Remove from wishlist"
                >
                  <FaTimes />
                </button>
              </div>

              <div className="p-4 flex flex-col gap-2">
                <div className="text-sm text-neutral-500">{product.brand}</div>
                <h4 className="text-lg font-semibold leading-tight">
                  <Link to={`/product/${product._id}`} className="hover:underline">{product.name}</Link>
                </h4>
                <div className="text-sm text-neutral-500">{product.category}</div>
                <div className="mt-2 text-xl font-bold">${Number(product.price || 0).toFixed(2)}</div>
                <div className="text-xs text-neutral-500">Added {new Date(item.addedAt).toLocaleDateString()}</div>

                <div className="mt-3 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => moveToCart(product._id)}
                    disabled={movingToCart[product._id]}
                    className="col-span-2 inline-flex items-center justify-center gap-2 rounded-xl bg-black text-white px-4 py-2 hover:opacity-90 disabled:opacity-60"
                  >
                    {movingToCart[product._id] ? 'Adding…' : (<><FaShoppingCart /> Add to Cart</>)}
                  </button>
                  <button
                    onClick={() => removeFromWishlist(product._id)}
                    disabled={removing[product._id]}
                    className="col-span-2 inline-flex items-center justify-center gap-2 rounded-xl border px-4 py-2 hover:bg-neutral-50 dark:hover:bg-neutral-800 disabled:opacity-60"
                  >
                    <FaTrash /> Remove
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8">
        <Link to="/" className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 hover:bg-neutral-50 dark:hover:bg-neutral-800">
          <FaArrowLeft /> Continue Shopping
        </Link>
      </div>
    </div>
  );
};

export default Wishlist;
