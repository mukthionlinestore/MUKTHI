import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import axios from '../config/axios';
import { FaSearch, FaShoppingCart, FaHeart, FaStar, FaFilter, FaTimes } from 'react-icons/fa';
import ProductCard from '../components/products/ProductCard';
import FilterSidebar from '../components/products/FilterSidebar';
import SortDropdown from '../components/products/SortDropdown';

const Home = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);

  // Debounced search to avoid too many API calls
  const debouncedSearch = useCallback(
    (() => {
      let timeoutId;
      return (term) => {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          setSearchTerm(term);
        }, 300); // 300ms delay
      };
    })(),
    []
  );

  useEffect(() => {
    fetchProducts();
    fetchCategories();
    fetchBrands();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCategory, selectedBrand, sortBy]);

  // Separate effect for search to avoid conflicts
  useEffect(() => {
    if (searchTerm !== undefined) {
      fetchProducts();
    }
  }, [searchTerm]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      setSearchLoading(true);
      setError(null);
      const params = new URLSearchParams();
      
      // Only add parameters if they have values
      if (searchTerm && searchTerm.trim()) params.append('search', searchTerm.trim());
      if (selectedCategory) params.append('category', selectedCategory);
      if (selectedBrand) params.append('brand', selectedBrand);
      if (sortBy) params.append('sort', sortBy);

      console.log('Fetching products with params:', params.toString());
      
      const response = await axios.get(`/api/products?${params}`);
      console.log('Products response:', response.data);
      
      setProducts(response.data.products || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      setError('Failed to load products. Please try again later.');
      setProducts([]);
    } finally {
      setLoading(false);
      setSearchLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/products/categories/list');
      setCategories(response.data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
      setCategories([]);
    }
  };

  const fetchBrands = async () => {
    try {
      const response = await axios.get('/api/products/brands/list');
      setBrands(response.data || []);
    } catch (error) {
      console.error('Error fetching brands:', error);
      setBrands([]);
    }
  };

  const handleSearchInput = (e) => {
    const value = e.target.value;
    debouncedSearch(value);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    // Search is already handled by useEffect when searchTerm changes
    console.log('Search submitted:', searchTerm);
  };

  const handleCategoryChange = (category) => {
    console.log('Category changed:', category);
    setSelectedCategory(category === selectedCategory ? '' : category);
  };

  const handleBrandChange = (brand) => {
    console.log('Brand changed:', brand);
    setSelectedBrand(brand === selectedBrand ? '' : brand);
  };

  const handleSortChange = (sort) => {
    console.log('Sort changed:', sort);
    setSortBy(sort);
  };

  const clearAll = () => {
    console.log('Clearing all filters');
    setSelectedCategory('');
    setSelectedBrand('');
    setSearchTerm('');
    setSortBy('newest');
  };

  const hasActiveFilters = useMemo(() => !!(selectedCategory || selectedBrand || searchTerm.trim()), [selectedCategory, selectedBrand, searchTerm]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-slate-50 to-white">
      {/* Hero */}
      <section className="relative isolate">
        <div className="mx-auto  px-4 sm:px-6 lg:px-8">
          <div className="py-10 sm:py-14">
            <div className="flex flex-col items-center text-center gap-4">
              <span className="inline-flex items-center rounded-full border border-slate-200 bg-white/60 px-3 py-1 text-xs font-medium text-slate-600 backdrop-blur">
                ✨ New deals drop every week
              </span>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900">
                Discover products you'll love
              </h1>
              <p className="max-w-2xl text-slate-600">
                Smart filters, instant search, and beautiful product cards — optimized for mobile & desktop.
              </p>

              {/* Search Bar */}
              <form onSubmit={handleSearch} className="w-full max-w-2xl">
                <div className="group relative flex items-center rounded-2xl border border-slate-200 bg-white shadow-sm focus-within:ring-2 focus-within:ring-slate-900/10">
                  <span className="pl-4 pr-2 text-slate-500">
                    {searchLoading ? (
                      <div className="w-4 h-4 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin" />
                    ) : (
                      <FaSearch aria-hidden />
                    )}
                  </span>
                  <input
                    type="text"
                    placeholder="Search products, brands, categories… (type any character to search)"
                    onChange={handleSearchInput}
                    className="w-full bg-transparent py-3.5 pr-28 text-sm outline-none placeholder:text-slate-400"
                    aria-label="Search products"
                  />
                  <div className="absolute right-2 inset-y-1 flex gap-2">
                    {searchTerm && (
                      <button
                        type="button"
                        onClick={() => {
                          setSearchTerm('');
                          debouncedSearch('');
                        }}
                        className="inline-flex items-center justify-center rounded-xl px-3 text-xs text-slate-600 hover:bg-slate-100"
                        aria-label="Clear search"
                      >
                        Clear
                      </button>
                    )}
                    <button type="submit" className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-4 text-sm font-medium text-white hover:bg-slate-800">
                      Search
                    </button>
                  </div>
                </div>
              </form>

              {/* Search feedback */}
              {searchTerm && (
                <div className="text-sm text-slate-600">
                  {searchLoading ? (
                    <span>🔍 Searching for "{searchTerm}"...</span>
                  ) : (
                    <span>📋 Showing results for "{searchTerm}"</span>
                  )}
                </div>
              )}

              {/* Quick filter chips on mobile */}
              <div className="flex flex-wrap items-center justify-center gap-2 pt-3 sm:hidden">
                <button
                  onClick={() => setMobileFiltersOpen(true)}
                  className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-700 shadow-sm"
                >
                  <FaFilter /> Filters
                </button>
                {hasActiveFilters && (
                  <button onClick={clearAll} className="text-sm text-slate-600 underline underline-offset-2">Clear all</button>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="mx-auto  px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Sidebar (desktop) */}
          <aside className="hidden lg:block lg:col-span-3">
            <div className="sticky top-4 space-y-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-900">Filters</h2>
                {hasActiveFilters && (
                  <button onClick={clearAll} className="text-sm text-slate-600 hover:underline">Reset</button>
                )}
              </div>
              <FilterSidebar
                categories={categories}
                brands={brands}
                selectedCategory={selectedCategory}
                selectedBrand={selectedBrand}
                onCategoryChange={handleCategoryChange}
                onBrandChange={handleBrandChange}
              />
            </div>
          </aside>

          {/* Content */}
          <div className="lg:col-span-9 space-y-4">
            {/* Toolbar */}
            <div className="flex items-center justify-between gap-3">
              {/* Active filters chips (desktop) */}
              <div className="hidden md:flex flex-wrap items-center gap-2">
                {selectedCategory && (
                  <Chip onClear={() => setSelectedCategory('')}>Category: {selectedCategory}</Chip>
                )}
                {selectedBrand && (
                  <Chip onClear={() => setSelectedBrand('')}>Brand: {selectedBrand}</Chip>
                )}
                {searchTerm && (
                  <Chip onClear={() => {
                    setSearchTerm('');
                    debouncedSearch('');
                  }}>Search: {searchTerm}</Chip>
                )}
                {hasActiveFilters && (
                  <button onClick={clearAll} className="text-sm text-slate-600 hover:underline">Clear all</button>
                )}
              </div>

              {/* Sort */}
              <div className="ml-auto">
                <SortDropdown sortBy={sortBy} onSortChange={handleSortChange} />
              </div>
            </div>

            {/* Debug Info (remove in production) */}
            {process.env.NODE_ENV === 'development' && (
              <div className="text-xs text-gray-500 bg-gray-100 p-2 rounded">
                Debug: Search="{searchTerm}" | Category="{selectedCategory}" | Brand="{selectedBrand}" | Sort="{sortBy}" | Products: {products.length} | Loading: {loading}
              </div>
            )}

            {/* Products Grid / States */}
            <div>
              {error ? (
                <ErrorState onRetry={fetchProducts} message={error} />
              ) : loading ? (
                <SkeletonGrid />
              ) : products.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
                  {products.map((product) => (
                    <ProductCard key={product._id} product={product} />
                  ))}
                </div>
              ) : (
                <EmptyState onReset={clearAll} searchTerm={searchTerm} />
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Mobile Filters Drawer */}
      {mobileFiltersOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-slate-900/50" onClick={() => setMobileFiltersOpen(false)} />
          <div className="absolute inset-y-0 right-0 w-full max-w-md bg-white shadow-xl animate-in slide-in-from-right">
            <div className="flex items-center justify-between border-b border-slate-200 p-4">
              <h3 className="text-base font-semibold text-slate-900">Filters</h3>
              <button
                className="inline-flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-100"
                onClick={() => setMobileFiltersOpen(false)}
                aria-label="Close"
              >
                <FaTimes />
              </button>
            </div>
            <div className="p-4">
              <FilterSidebar
                categories={categories}
                brands={brands}
                selectedCategory={selectedCategory}
                selectedBrand={selectedBrand}
                onCategoryChange={handleCategoryChange}
                onBrandChange={handleBrandChange}
              />
            </div>
            <div className="sticky bottom-0 border-t border-slate-200 bg-white p-4 flex items-center justify-end gap-2">
              <button onClick={clearAll} className="text-sm text-slate-600 hover:underline mr-auto">Reset</button>
              <button
                onClick={() => setMobileFiltersOpen(false)}
                className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ---------------------- Small UI helpers ---------------------- */
const Chip = ({ children, onClear }) => (
  <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-700 shadow-sm">
    {children}
    <button
      onClick={onClear}
      className="-mr-1 inline-flex h-5 w-5 items-center justify-center rounded-full hover:bg-slate-100"
      aria-label="Remove filter"
    >
      <FaTimes className="text-[10px]" />
    </button>
  </span>
);

const SkeletonGrid = () => {
  const items = Array.from({ length: 8 });
  return (
    <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
      {items.map((_, idx) => (
        <div key={idx} className="rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
          <div className="aspect-square w-full rounded-xl bg-slate-100 animate-pulse" />
          <div className="mt-3 h-4 w-3/4 rounded bg-slate-100 animate-pulse" />
          <div className="mt-2 h-4 w-1/2 rounded bg-slate-100 animate-pulse" />
          <div className="mt-3 h-9 w-full rounded-lg bg-slate-100 animate-pulse" />
        </div>
      ))}
    </div>
  );
};

const ErrorState = ({ message, onRetry }) => (
  <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center shadow-sm">
    <div className="mx-auto mb-3 h-10 w-10 rounded-full bg-red-100 flex items-center justify-center">⚠️</div>
    <h3 className="text-lg font-semibold text-red-800">Something went wrong</h3>
    <p className="mt-1 text-sm text-red-700">{message}</p>
    <button onClick={onRetry} className="mt-4 rounded-xl bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700">Try again</button>
  </div>
);

const EmptyState = ({ onReset, searchTerm }) => (
  <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center shadow-sm">
    <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-slate-100 flex items-center justify-center">🔎</div>
    <h3 className="text-lg font-semibold text-slate-900">
      {searchTerm ? `No products found for "${searchTerm}"` : 'No products found'}
    </h3>
    <p className="mt-1 text-sm text-slate-600">
      {searchTerm ? 'Try adjusting your search terms or filters.' : 'Try adjusting your filters.'}
    </p>
    <div className="mt-6 flex items-center justify-center gap-2">
      <button onClick={onReset} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800">Clear all</button>
      <Link to="/" className="text-sm text-slate-700 underline underline-offset-2">Go to home</Link>
    </div>
  </div>
);

export default Home;
