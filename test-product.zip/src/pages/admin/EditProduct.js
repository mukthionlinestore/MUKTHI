import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../../config/axios';
import { FaUpload, FaTrash, FaPlus, FaSave, FaArrowLeft, FaCloudUploadAlt } from 'react-icons/fa';
import { toast } from 'react-toastify';

const EditProduct = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [imageUploading, setImageUploading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    originalPrice: '',
    quantity: '',
    category: '',
    brand: '',
    images: [],
    thumbnailIndex: 0,
    colors: [],
    sizes: [],
    features: [],
    isNew: false,
    isSold: false
  });

  useEffect(() => {
    fetchProduct();
    fetchCategories();
    fetchBrands();
  }, [id]);

  const fetchProduct = async () => {
    try {
      const response = await axios.get(`/api/admin/products/${id}`);
      const product = response.data;
      
      setFormData({
        name: product.name || '',
        description: product.description || '',
        price: product.price || '',
        originalPrice: product.originalPrice || '',
        quantity: product.quantity || '',
        category: product.category || '',
        brand: product.brand || '',
        images: product.images || [],
        thumbnailIndex: product.thumbnailIndex || 0,
        colors: product.colors || [],
        sizes: product.sizes || [],
        features: product.features || [],
        isNew: product.isNew || false,
        isSold: product.isSold || false
      });
    } catch (error) {
      toast.error('Failed to load product');
      console.error('Error fetching product:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/products/categories/list');
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchBrands = async () => {
    try {
      const response = await axios.get('/api/products/brands/list');
      setBrands(response.data);
    } catch (error) {
      console.error('Error fetching brands:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    
    if (files.length === 0) return;
    
    setImageUploading(true);
    
    try {
      // Convert files to base64
      const imagePromises = files.map(file => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target.result);
          reader.readAsDataURL(file);
        });
      });

      const base64Images = await Promise.all(imagePromises);
      
      // Upload to Cloudinary via backend
      const response = await axios.post('/api/upload/base64-images', {
        images: base64Images
      });

      const cloudinaryUrls = response.data.images.map(img => img.url);
      
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...cloudinaryUrls]
      }));
      
      toast.success(`${files.length} image(s) uploaded successfully!`);
    } catch (error) {
      console.error('Image upload error:', error);
      toast.error('Failed to upload images. Please try again.');
    } finally {
      setImageUploading(false);
    }
  };

  const removeImage = async (index) => {
    const imageUrl = formData.images[index];
    
    try {
      // Delete from Cloudinary if it's a Cloudinary URL
      if (imageUrl && imageUrl.includes('cloudinary.com')) {
        await axios.delete('/api/upload/images', {
          data: { url: imageUrl }
        });
      }
      
      setFormData(prev => ({
        ...prev,
        images: prev.images.filter((_, i) => i !== index),
        thumbnailIndex: prev.thumbnailIndex >= index ? Math.max(0, prev.thumbnailIndex - 1) : prev.thumbnailIndex
      }));
      
      toast.success('Image removed successfully!');
    } catch (error) {
      console.error('Error removing image:', error);
      toast.error('Failed to remove image. Please try again.');
    }
  };

  const setThumbnail = (index) => {
    setFormData(prev => ({
      ...prev,
      thumbnailIndex: index
    }));
  };

  const addColor = () => {
    setFormData(prev => ({
      ...prev,
      colors: [...prev.colors, { name: '', code: '#000000' }]
    }));
  };

  const removeColor = (index) => {
    setFormData(prev => ({
      ...prev,
      colors: prev.colors.filter((_, i) => i !== index)
    }));
  };

  const updateColor = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      colors: prev.colors.map((color, i) => 
        i === index ? { ...color, [field]: value } : color
      )
    }));
  };

  const addSize = () => {
    setFormData(prev => ({
      ...prev,
      sizes: [...prev.sizes, { name: '', available: true }]
    }));
  };

  const removeSize = (index) => {
    setFormData(prev => ({
      ...prev,
      sizes: prev.sizes.filter((_, i) => i !== index)
    }));
  };

  const updateSize = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      sizes: prev.sizes.map((size, i) => 
        i === index ? { ...size, [field]: value } : size
      )
    }));
  };

  const addFeature = () => {
    setFormData(prev => ({
      ...prev,
      features: [...prev.features, '']
    }));
  };

  const removeFeature = (index) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const updateFeature = (index, value) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.map((feature, i) => 
        i === index ? value : feature
      )
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      // Filter out empty colors, sizes, and features
      const cleanedData = {
        ...formData,
        colors: formData.colors.filter(color => color.name.trim()),
        sizes: formData.sizes.filter(size => size.name.trim()),
        features: formData.features.filter(feature => feature.trim())
      };

      await axios.put(`/api/admin/products/${id}`, cleanedData);
      toast.success('Product updated successfully!');
      navigate('/admin/products');
    } catch (error) {
      toast.error('Failed to update product');
      console.error('Error updating product:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="admin-page">
        <div className="container">
          <div className="loading-spinner">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div className="container">
        <div className="page-header">
          <button onClick={() => navigate('/admin/products')} className="btn btn-outline">
            <FaArrowLeft />
            Back to Products
          </button>
          <h1>Edit Product</h1>
          <p>Update product information</p>
        </div>

        <form onSubmit={handleSubmit} className="product-form">
          <div className="form-grid">
            {/* Basic Information */}
            <div className="form-section">
              <h3>Basic Information</h3>
              
              <div className="form-group">
                <label htmlFor="name">Product Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="form-control"
                />
              </div>

              <div className="form-group">
                <label htmlFor="description">Description *</label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  required
                  rows="4"
                  className="form-control"
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="price">Price *</label>
                  <input
                    type="number"
                    id="price"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                    min="0"
                    step="0.01"
                    className="form-control"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="originalPrice">Original Price</label>
                  <input
                    type="number"
                    id="originalPrice"
                    name="originalPrice"
                    value={formData.originalPrice}
                    onChange={handleInputChange}
                    min="0"
                    step="0.01"
                    className="form-control"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="quantity">Quantity *</label>
                  <input
                    type="number"
                    id="quantity"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInputChange}
                    required
                    min="0"
                    className="form-control"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="category">Category *</label>
                  <input
                    type="text"
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    required
                    className="form-control"
                    list="categories"
                  />
                  <datalist id="categories">
                    {categories.map(cat => (
                      <option key={cat} value={cat} />
                    ))}
                  </datalist>
                </div>

                <div className="form-group">
                  <label htmlFor="brand">Brand</label>
                  <input
                    type="text"
                    id="brand"
                    name="brand"
                    value={formData.brand}
                    onChange={handleInputChange}
                    className="form-control"
                    list="brands"
                  />
                  <datalist id="brands">
                    {brands.map(brand => (
                      <option key={brand} value={brand} />
                    ))}
                  </datalist>
                </div>
              </div>
            </div>

            {/* Images */}
            <div className="form-section">
              <h3>Product Images</h3>
              
              <div className="form-group">
                <label htmlFor="images">Upload Images</label>
                <input
                  type="file"
                  id="images"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="form-control"
                  disabled={imageUploading}
                />
                {imageUploading && (
                  <p className="text-muted mt-2">Uploading images...</p>
                )}
              </div>

              {formData.images.length > 0 && (
                <div className="images-grid">
                  {formData.images.map((image, index) => (
                    <div key={index} className="image-item">
                      <img src={image} alt={`Product ${index + 1}`} />
                      <div className="image-actions">
                        <button
                          type="button"
                          onClick={() => setThumbnail(index)}
                          className={`btn btn-sm ${formData.thumbnailIndex === index ? 'btn-primary' : 'btn-outline'}`}
                        >
                          {formData.thumbnailIndex === index ? 'Thumbnail' : 'Set Thumbnail'}
                        </button>
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="btn btn-sm btn-danger"
                        >
                          <FaTrash />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Colors */}
            <div className="form-section">
              <h3>Colors</h3>
              <button type="button" onClick={addColor} className="btn btn-outline">
                <FaPlus />
                Add Color
              </button>

              {formData.colors.map((color, index) => (
                <div key={index} className="color-item">
                  <input
                    type="text"
                    placeholder="Color name"
                    value={color.name}
                    onChange={(e) => updateColor(index, 'name', e.target.value)}
                    className="form-control"
                  />
                  <input
                    type="color"
                    value={color.code}
                    onChange={(e) => updateColor(index, 'code', e.target.value)}
                    className="form-control"
                  />
                  <button
                    type="button"
                    onClick={() => removeColor(index)}
                    className="btn btn-danger"
                  >
                    <FaTrash />
                  </button>
                </div>
              ))}
            </div>

            {/* Sizes */}
            <div className="form-section">
              <h3>Sizes</h3>
              <button type="button" onClick={addSize} className="btn btn-outline">
                <FaPlus />
                Add Size
              </button>

              {formData.sizes.map((size, index) => (
                <div key={index} className="size-item">
                  <input
                    type="text"
                    placeholder="Size name"
                    value={size.name}
                    onChange={(e) => updateSize(index, 'name', e.target.value)}
                    className="form-control"
                  />
                  <label>
                    <input
                      type="checkbox"
                      checked={size.available}
                      onChange={(e) => updateSize(index, 'available', e.target.checked)}
                    />
                    Available
                  </label>
                  <button
                    type="button"
                    onClick={() => removeSize(index)}
                    className="btn btn-danger"
                  >
                    <FaTrash />
                  </button>
                </div>
              ))}
            </div>

            {/* Features */}
            <div className="form-section">
              <h3>Features</h3>
              <button type="button" onClick={addFeature} className="btn btn-outline">
                <FaPlus />
                Add Feature
              </button>

              {formData.features.map((feature, index) => (
                <div key={index} className="feature-item">
                  <input
                    type="text"
                    placeholder="Feature description"
                    value={feature}
                    onChange={(e) => updateFeature(index, e.target.value)}
                    className="form-control"
                  />
                  <button
                    type="button"
                    onClick={() => removeFeature(index)}
                    className="btn btn-danger"
                  >
                    <FaTrash />
                  </button>
                </div>
              ))}
            </div>

            {/* Status */}
            <div className="form-section">
              <h3>Status</h3>
              <div className="form-row">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    name="isNew"
                    checked={formData.isNew}
                    onChange={handleInputChange}
                  />
                  Mark as New
                </label>

                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    name="isSold"
                    checked={formData.isSold}
                    onChange={handleInputChange}
                  />
                  Mark as Sold
                </label>
              </div>
            </div>
          </div>

          <div className="form-actions">
            <button type="submit" className="btn btn-primary" disabled={saving}>
              <FaSave />
              {saving ? 'Updating...' : 'Update Product'}
            </button>
            <button type="button" onClick={() => navigate('/admin/products')} className="btn btn-outline">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProduct;
