import React, { useState, useEffect } from 'react';
import axios from '../../config/axios';
import { FaPlus, FaEdit, FaTrash, FaSave, FaTimes, FaList, FaChartBar } from 'react-icons/fa';
import { toast } from 'react-toastify';

const ManageCategories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newCategory, setNewCategory] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editingName, setEditingName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/admin/categories/stats');
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error('Failed to load categories');
    } finally {
      setLoading(false);
    }
  };

  const handleAddCategory = async (e) => {
    e.preventDefault();
    if (!newCategory.trim() || submitting) return;

    try {
      setSubmitting(true);
      await axios.post('/api/admin/categories', { name: newCategory.trim() });
      toast.success('Category added successfully!');
      setNewCategory('');
      fetchCategories();
    } catch (error) {
      console.error('Error adding category:', error);
      toast.error(error.response?.data?.message || 'Failed to add category');
    } finally {
      setSubmitting(false);
    }
  };

  const startEditing = (category) => {
    setEditingId(category.name);
    setEditingName(category.name);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditingName('');
  };

  const handleUpdateCategory = async (oldName) => {
    if (!editingName.trim() || editingName === oldName || submitting) {
      cancelEditing();
      return;
    }

    try {
      setSubmitting(true);
      await axios.put(`/api/admin/categories/${encodeURIComponent(oldName)}`, {
        name: editingName.trim()
      });
      toast.success('Category updated successfully!');
      cancelEditing();
      fetchCategories();
    } catch (error) {
      console.error('Error updating category:', error);
      toast.error(error.response?.data?.message || 'Failed to update category');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteCategory = async (categoryName) => {
    if (!window.confirm(`Are you sure you want to delete "${categoryName}"? This action cannot be undone.`)) {
      return;
    }

    try {
      setSubmitting(true);
      await axios.delete(`/api/admin/categories/${encodeURIComponent(categoryName)}`);
      toast.success('Category deleted successfully!');
      fetchCategories();
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error(error.response?.data?.message || 'Failed to delete category');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="admin-page">
        <div className="container">
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading categories...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div className="container">
        {/* Page Header */}
        <div className="page-header">
          <div className="header-content">
            <div className="header-left">
              <h1>Manage Categories</h1>
              <p>Organize your products with categories and subcategories</p>
            </div>
            <div className="header-stats">
              <div className="stat-item">
                <FaList />
                <span>{categories.length} Categories</span>
              </div>
            </div>
          </div>
        </div>

        {/* Add New Category */}
        <div className="admin-card">
          <div className="card-header">
            <h3><FaPlus /> Add New Category</h3>
          </div>
          <div className="card-body">
            <form onSubmit={handleAddCategory} className="add-form">
              <div className="form-group">
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="Enter category name (e.g., Electronics, Clothing, Books)"
                  className="form-control"
                  required
                  disabled={submitting}
                />
              </div>
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={submitting || !newCategory.trim()}
              >
                {submitting ? 'Adding...' : 'Add Category'}
              </button>
            </form>
          </div>
        </div>

        {/* Categories List */}
        <div className="admin-card">
          <div className="card-header">
            <h3><FaList /> Existing Categories</h3>
            <span className="category-count">{categories.length} categories</span>
          </div>
          <div className="card-body">
            {categories.length === 0 ? (
              <div className="empty-state">
                <FaList />
                <h4>No categories found</h4>
                <p>Add your first category to start organizing your products</p>
              </div>
            ) : (
              <div className="categories-grid">
                {categories.map((category) => (
                  <div key={category.name} className="category-card">
                    <div className="category-header">
                      <div className="category-info">
                        <h4>{category.name}</h4>
                        <span className="product-count">
                          <FaChartBar /> {category.count} products
                        </span>
                      </div>
                      <div className="category-actions">
                        {editingId === category.name ? (
                          <div className="edit-actions">
                            <button
                              onClick={() => handleUpdateCategory(category.name)}
                              className="btn btn-sm btn-primary"
                              disabled={submitting}
                            >
                              <FaSave />
                            </button>
                            <button
                              onClick={cancelEditing}
                              className="btn btn-sm btn-outline"
                              disabled={submitting}
                            >
                              <FaTimes />
                            </button>
                          </div>
                        ) : (
                          <div className="view-actions">
                            <button
                              onClick={() => startEditing(category)}
                              className="btn btn-sm btn-outline"
                              title="Edit category"
                            >
                              <FaEdit />
                            </button>
                            <button
                              onClick={() => handleDeleteCategory(category.name)}
                              className="btn btn-sm btn-danger"
                              title="Delete category"
                              disabled={submitting}
                            >
                              <FaTrash />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {editingId === category.name && (
                      <div className="edit-form">
                        <input
                          type="text"
                          value={editingName}
                          onChange={(e) => setEditingName(e.target.value)}
                          className="form-control"
                          autoFocus
                          disabled={submitting}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageCategories;
