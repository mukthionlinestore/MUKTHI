import React, { useState, useEffect } from 'react';
import axios from '../../config/axios';
import { FaPlus, FaEdit, FaTrash, FaSave, FaTimes, FaStar, FaChartBar } from 'react-icons/fa';
import { toast } from 'react-toastify';

const ManageBrands = () => {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newBrand, setNewBrand] = useState({
    name: '',
    description: '',
    website: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [editingBrand, setEditingBrand] = useState({
    name: '',
    description: '',
    website: ''
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchBrands();
  }, []);

  const fetchBrands = async () => {
    try {
      setLoading(true);
      // Use the stats endpoint to get brands with product counts
      const response = await axios.get('/api/admin/brands/stats');
      console.log('Fetched brands:', response.data); // Debug log
      
      // The response should be an array of brands with counts
      if (Array.isArray(response.data)) {
        setBrands(response.data);
      } else {
        console.error('Unexpected response format:', response.data);
        setBrands([]);
      }
    } catch (error) {
      console.error('Error fetching brands:', error);
      toast.error('Failed to load brands. Please check your API connection.');
      setBrands([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAddBrand = async (e) => {
    e.preventDefault();
    if (!newBrand.name.trim() || submitting) return;

    try {
      setSubmitting(true);
      console.log('Adding brand:', newBrand); // Debug log
      
      const brandData = {
        name: newBrand.name.trim(),
        description: newBrand.description.trim() || '',
        website: newBrand.website.trim() || '',
        logo: '' // You can add logo field later if needed
      };

      const response = await axios.post('/api/admin/brands', brandData);
      console.log('Add brand response:', response.data); // Debug log
      
      toast.success('Brand added successfully!');
      setNewBrand({ name: '', description: '', website: '' });
      await fetchBrands(); // Refresh the list
    } catch (error) {
      console.error('Error adding brand:', error);
      console.error('Error response:', error.response?.data); // Debug log
      toast.error(error.response?.data?.message || 'Failed to add brand');
    } finally {
      setSubmitting(false);
    }
  };

  const startEditing = (brand) => {
    console.log('Editing brand:', brand); // Debug log
    setEditingId(brand._id);
    setEditingBrand({
      name: brand.name || '',
      description: brand.description || '',
      website: brand.website || ''
    });
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditingBrand({ name: '', description: '', website: '' });
  };

  const handleUpdateBrand = async (brandId) => {
    if (!editingBrand.name.trim() || submitting) {
      cancelEditing();
      return;
    }

    try {
      setSubmitting(true);
      console.log('Updating brand:', brandId, editingBrand); // Debug log
      
      const updateData = {
        name: editingBrand.name.trim(),
        description: editingBrand.description.trim() || '',
        website: editingBrand.website.trim() || '',
        logo: '' // You can add logo field later if needed
      };

      const response = await axios.put(`/api/admin/brands/${brandId}`, updateData);
      console.log('Update brand response:', response.data); // Debug log
      
      toast.success('Brand updated successfully!');
      cancelEditing();
      await fetchBrands();
    } catch (error) {
      console.error('Error updating brand:', error);
      toast.error(error.response?.data?.message || 'Failed to update brand');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteBrand = async (brand) => {
    const brandName = brand.name || 'this brand';
    const brandId = brand._id;
    
    if (!window.confirm(`Are you sure you want to delete "${brandName}"? This action cannot be undone.`)) {
      return;
    }

    try {
      setSubmitting(true);
      console.log('Deleting brand:', brandId); // Debug log
      
      const response = await axios.delete(`/api/admin/brands/${brandId}`);
      console.log('Delete brand response:', response.data); // Debug log
      
      toast.success('Brand deleted successfully!');
      await fetchBrands();
    } catch (error) {
      console.error('Error deleting brand:', error);
      toast.error(error.response?.data?.message || 'Failed to delete brand');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="admin-page">
        <div className="container">
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading brands...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div className="container">
        {/* Page Header */}
        <div className="page-header">
          <div className="header-content">
            <div className="header-left">
              <h1>Manage Brands</h1>
              <p>Add and manage product brands and manufacturers</p>
            </div>
            <div className="header-stats">
              <div className="stat-item">
                <FaStar />
                <span>{brands.length} Brands</span>
              </div>
            </div>
          </div>
        </div>

        {/* Add New Brand */}
        <div className="admin-card">
          <div className="card-header">
            <h3><FaPlus /> Add New Brand</h3>
          </div>
          <div className="card-body">
            <form onSubmit={handleAddBrand} className="add-form">
              <div className="form-group">
                <input
                  type="text"
                  value={newBrand.name}
                  onChange={(e) => setNewBrand({ ...newBrand, name: e.target.value })}
                  placeholder="Enter brand name (e.g., Apple, Samsung, Nike)"
                  className="form-control"
                  required
                  disabled={submitting}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  value={newBrand.description}
                  onChange={(e) => setNewBrand({ ...newBrand, description: e.target.value })}
                  placeholder="Brand description (optional)"
                  className="form-control"
                  disabled={submitting}
                />
              </div>
              <div className="form-group">
                <input
                  type="url"
                  value={newBrand.website}
                  onChange={(e) => setNewBrand({ ...newBrand, website: e.target.value })}
                  placeholder="Website URL (optional)"
                  className="form-control"
                  disabled={submitting}
                />
              </div>
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={submitting || !newBrand.name.trim()}
              >
                {submitting ? 'Adding...' : 'Add Brand'}
              </button>
            </form>
          </div>
        </div>

        {/* Brands List */}
        <div className="admin-card">
          <div className="card-header">
            <h3><FaStar /> Existing Brands</h3>
            <span className="brand-count">{brands.length} brands</span>
          </div>
          <div className="card-body">
            {brands.length === 0 ? (
              <div className="empty-state">
                <FaStar />
                <h4>No brands found</h4>
                <p>Add your first brand to start organizing your products</p>
              </div>
            ) : (
              <div className="brands-grid">
                {brands.map((brand) => {
                  const brandId = brand._id;
                  const isEditing = editingId === brandId;
                  
                  return (
                    <div key={brandId} className="brand-card">
                      <div className="brand-header">
                        <div className="brand-info">
                          {isEditing ? (
                            <div className="edit-form">
                              <input
                                type="text"
                                value={editingBrand.name}
                                onChange={(e) => setEditingBrand({ ...editingBrand, name: e.target.value })}
                                className="form-control mb-2"
                                placeholder="Brand name"
                                autoFocus
                                disabled={submitting}
                              />
                              <input
                                type="text"
                                value={editingBrand.description}
                                onChange={(e) => setEditingBrand({ ...editingBrand, description: e.target.value })}
                                className="form-control mb-2"
                                placeholder="Description"
                                disabled={submitting}
                              />
                              <input
                                type="url"
                                value={editingBrand.website}
                                onChange={(e) => setEditingBrand({ ...editingBrand, website: e.target.value })}
                                className="form-control mb-2"
                                placeholder="Website URL"
                                disabled={submitting}
                              />
                            </div>
                          ) : (
                            <>
                              <h4>{brand.name}</h4>
                              {brand.description && (
                                <p className="brand-description">{brand.description}</p>
                              )}
                              {brand.website && (
                                <a href={brand.website} target="_blank" rel="noopener noreferrer" className="brand-website">
                                  {brand.website}
                                </a>
                              )}
                              <span className="product-count">
                                <FaChartBar /> {brand.productCount || 0} products
                              </span>
                            </>
                          )}
                        </div>
                        <div className="brand-actions">
                          {isEditing ? (
                            <div className="edit-actions">
                              <button
                                onClick={() => handleUpdateBrand(brandId)}
                                className="btn btn-sm btn-primary"
                                disabled={submitting}
                              >
                                <FaSave />
                              </button>
                              <button
                                onClick={cancelEditing}
                                className="btn btn-sm btn-outline"
                                disabled={submitting}
                              >
                                <FaTimes />
                              </button>
                            </div>
                          ) : (
                            <div className="view-actions">
                              <button
                                onClick={() => startEditing(brand)}
                                className="btn btn-sm btn-outline"
                                title="Edit brand"
                              >
                                <FaEdit />
                              </button>
                              <button
                                onClick={() => handleDeleteBrand(brand)}
                                className="btn btn-sm btn-danger"
                                title="Delete brand"
                                disabled={submitting}
                              >
                                <FaTrash />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageBrands;