import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../../config/axios';
import { 
  FaPlus, 
  FaEdit, 
  FaTrash, 
  FaSearch, 
  FaEye, 
  FaFilter, 
  FaSort, 
  FaBox,
  FaEyeSlash,
  FaCheckCircle,
  FaExclamationTriangle,
  FaDownload,
  FaUpload,
  FaSync,
  FaTimes,
  FaCog,
  FaChartBar,
  FaStar,
  FaTag
} from 'react-icons/fa';
import { toast } from 'react-toastify';

const AdminProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalProducts, setTotalProducts] = useState(0);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [filters, setFilters] = useState({
    category: '',
    brand: '',
    status: ''
  });
  const [sortBy, setSortBy] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [bulkActions, setBulkActions] = useState(false);

  useEffect(() => {
    fetchProducts();
    fetchCategories();
    fetchBrands();
  }, [currentPage, searchTerm, filters, sortBy]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: currentPage,
        search: searchTerm,
        sort: sortBy,
        ...filters
      });
      
      console.log('Fetching products with params:', params.toString());
      const response = await axios.get(`/api/admin/products?${params}`);
      
      console.log('Products fetched:', {
        count: response.data.products?.length || 0,
        total: response.data.total,
        totalPages: response.data.totalPages
      });
      
      setProducts(response.data.products);
      setTotalPages(response.data.totalPages);
      setTotalProducts(response.data.total);
    } catch (error) {
      console.error('Error fetching products:', {
        status: error.response?.status,
        data: error.response?.data,
        message: error.message
      });
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/products/categories/list');
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchBrands = async () => {
    try {
      const response = await axios.get('/api/products/brands/list');
      setBrands(response.data);
    } catch (error) {
      console.error('Error fetching brands:', error);
    }
  };

  const handleDelete = async (productId) => {
    if (!window.confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
      return;
    }

    try {
      console.log('Deleting product:', productId);
      const response = await axios.delete(`/api/admin/products/${productId}`);
      
      console.log('Delete response:', response.data);
      
      // Check if there's a warning about Cloudinary cleanup
      if (response.data.warning) {
        toast.warning(response.data.message);
        console.warn('Product deleted with warning:', response.data.warning);
      } else {
        toast.success('Product deleted successfully');
      }
      
      // Remove the product from local state immediately for better UX
      setProducts(prevProducts => prevProducts.filter(p => p._id !== productId));
      
      // Add a small delay to ensure the database transaction is committed, then refresh
      setTimeout(() => {
        fetchProducts();
      }, 500);
      
    } catch (error) {
      console.error('Delete error details:', {
        status: error.response?.status,
        data: error.response?.data,
        message: error.message
      });
      
      // Check if the error response indicates the product was actually deleted
      if (error.response && error.response.status === 200) {
        toast.success(error.response.data.message || 'Product deleted successfully');
        // Remove the product from local state immediately for better UX
        setProducts(prevProducts => prevProducts.filter(p => p._id !== productId));
        setTimeout(() => {
          fetchProducts();
        }, 500);
      } else {
        toast.error(error.response?.data?.message || 'Failed to delete product');
        console.error('Error deleting product:', error);
      }
    }
  };

  const handleToggleSold = async (productId, currentStatus) => {
    try {
      await axios.put(`/api/admin/products/${productId}/sold`);
      toast.success(`Product marked as ${currentStatus ? 'available' : 'sold'}`);
      fetchProducts();
    } catch (error) {
      toast.error('Failed to update product status');
      console.error('Error updating product status:', error);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setCurrentPage(1);
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const clearFilters = () => {
    setFilters({ category: '', brand: '', status: '' });
    setSearchTerm('');
    setSortBy('newest');
    setCurrentPage(1);
  };

  const handleProductSelect = (productId) => {
    setSelectedProducts(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const handleSelectAll = () => {
    if (selectedProducts.length === products.length) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(products.map(p => p._id));
    }
  };

  const getStatusBadge = (product) => {
    if (product.isSold) {
      return (
        <span className="status-badge status-sold">
          <FaCheckCircle /> Sold
        </span>
      );
    }
    if (product.quantity === 0) {
      return (
        <span className="status-badge status-out-of-stock">
          <FaExclamationTriangle /> Out of Stock
        </span>
      );
    }
    if (product.quantity < 10) {
      return (
        <span className="status-badge status-low-stock">
          <FaExclamationTriangle /> Low Stock
        </span>
      );
    }
    return (
      <span className="status-badge status-available">
        <FaCheckCircle /> Available
      </span>
    );
  };

  const getStockLevel = (quantity) => {
    if (quantity === 0) return 'out-of-stock';
    if (quantity < 10) return 'low-stock';
    if (quantity < 50) return 'medium-stock';
    return 'high-stock';
  };

  if (loading) {
    return (
      <div className="admin-page">
        <div className="container">
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading products...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div className="container">
        {/* Page Header */}
        <div className="page-header">
          <div className="header-content">
            <div className="header-left">
              <h1>Manage Products</h1>
              <p>View, edit, and manage your product catalog</p>
            </div>
            <div className="header-stats">
              <div className="stat-item">
                <FaBox />
                <span>{totalProducts} Products</span>
              </div>
              <div className="stat-item">
                <FaChartBar />
                <span>{categories.length} Categories</span>
              </div>
              <div className="stat-item">
                <FaStar />
                <span>{brands.length} Brands</span>
              </div>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="admin-card">
          <div className="card-header">
            <h3><FaSearch /> Search & Filters</h3>
            <div className="header-actions">
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className="btn btn-outline btn-sm"
              >
                <FaFilter /> {showFilters ? 'Hide' : 'Show'} Filters
              </button>
              <button 
                onClick={fetchProducts}
                className="btn btn-outline btn-sm"
                title="Refresh"
              >
                <FaSync />
              </button>
            </div>
          </div>
          <div className="card-body">
            <form onSubmit={handleSearch} className="search-form">
              <div className="search-input-group">
                <div className="search-icon">
                  <FaSearch />
                </div>
                <input
                  type="text"
                  placeholder="Search products by name, description, category, or brand..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="form-control search-input"
                />
                <button type="submit" className="btn btn-primary">
                  Search
                </button>
              </div>
            </form>

            {showFilters && (
              <div className="filters-section">
                <div className="filters-grid">
                  <div className="filter-group">
                    <label><FaTag /> Category</label>
                    <select
                      value={filters.category}
                      onChange={(e) => handleFilterChange('category', e.target.value)}
                      className="form-control"
                    >
                      <option value="">All Categories</option>
                      {categories.map(category => (
                        <option key={category} value={category}>{category}</option>
                      ))}
                    </select>
                  </div>

                  <div className="filter-group">
                    <label><FaStar /> Brand</label>
                    <select
                      value={filters.brand}
                      onChange={(e) => handleFilterChange('brand', e.target.value)}
                      className="form-control"
                    >
                      <option value="">All Brands</option>
                      {brands.map(brand => (
                        <option key={brand} value={brand}>{brand}</option>
                      ))}
                    </select>
                  </div>

                  <div className="filter-group">
                    <label><FaCog /> Status</label>
                    <select
                      value={filters.status}
                      onChange={(e) => handleFilterChange('status', e.target.value)}
                      className="form-control"
                    >
                      <option value="">All Status</option>
                      <option value="available">Available</option>
                      <option value="sold">Sold</option>
                      <option value="out-of-stock">Out of Stock</option>
                      <option value="low-stock">Low Stock</option>
                    </select>
                  </div>

                  <div className="filter-group">
                    <label><FaSort /> Sort By</label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="form-control"
                    >
                      <option value="newest">Newest First</option>
                      <option value="oldest">Oldest First</option>
                      <option value="price_asc">Price: Low to High</option>
                      <option value="price_desc">Price: High to Low</option>
                      <option value="name_asc">Name: A to Z</option>
                      <option value="name_desc">Name: Z to A</option>
                    </select>
                  </div>
                </div>

                <div className="filter-actions">
                  <button onClick={clearFilters} className="btn btn-outline">
                    <FaTimes /> Clear Filters
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions Bar */}
        <div className="actions-bar">
          <div className="results-info">
            <span className="results-count">Showing {products.length} of {totalProducts} products</span>
            {selectedProducts.length > 0 && (
              <span className="selected-count">
                {selectedProducts.length} selected
              </span>
            )}
          </div>
          <div className="action-buttons">
            {selectedProducts.length > 0 && (
              <div className="bulk-actions">
                <button className="btn btn-outline btn-sm">
                  <FaDownload /> Export
                </button>
                <button className="btn btn-warning btn-sm">
                  <FaUpload /> Bulk Update
                </button>
                <button className="btn btn-danger btn-sm">
                  <FaTrash /> Delete Selected
                </button>
              </div>
            )}
            <Link to="/admin/products/add" className="btn btn-primary">
              <FaPlus />
              Add Product
            </Link>
          </div>
        </div>

        {/* Products Table */}
        <div className="admin-card">
          <div className="card-body">
            {products.length === 0 ? (
              <div className="empty-state">
                <FaBox />
                <h4>No products found</h4>
                <p>Try adjusting your search or filters, or add your first product!</p>
                <Link to="/admin/products/add" className="btn btn-primary">
                  <FaPlus />
                  Add Product
                </Link>
              </div>
            ) : (
              <div className="products-table-container">
                <table className="products-table">
                  <thead>
                    <tr>
                      <th className="checkbox-column">
                        <input
                          type="checkbox"
                          checked={selectedProducts.length === products.length}
                          onChange={handleSelectAll}
                          className="select-all-checkbox"
                        />
                      </th>
                      <th>Product</th>
                      <th>Category</th>
                      <th>Brand</th>
                      <th>Price</th>
                      <th>Stock</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product._id} className="product-row">
                        <td className="checkbox-column">
                          <input
                            type="checkbox"
                            checked={selectedProducts.includes(product._id)}
                            onChange={() => handleProductSelect(product._id)}
                            className="product-checkbox"
                          />
                        </td>
                        <td>
                          <div className="product-info">
                            <img 
                              src={product.images[product.thumbnailIndex || 0]} 
                              alt={product.name}
                              className="product-thumbnail"
                            />
                            <div className="product-details">
                              <h4 className="product-name">{product.name}</h4>
                              <p className="product-description">
                                {product.description?.substring(0, 60)}...
                              </p>
                              <div className="product-meta">
                                <span className="product-id">ID: {product._id.slice(-6)}</span>
                                <span className="product-date">
                                  {new Date(product.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td>
                          <span className="category-badge">
                            <FaTag /> {product.category}
                          </span>
                        </td>
                        <td>
                          <span className="brand-badge">
                            <FaStar /> {product.brand || 'No Brand'}
                          </span>
                        </td>
                        <td>
                          <div className="price-info">
                            <span className="price">${product.price.toFixed(2)}</span>
                            {product.originalPrice && product.originalPrice > product.price && (
                              <span className="original-price">${product.originalPrice.toFixed(2)}</span>
                            )}
                          </div>
                        </td>
                        <td>
                          <div className="stock-info">
                            <span className={`quantity ${getStockLevel(product.quantity)}`}>
                              {product.quantity}
                            </span>
                            <div className="stock-bar">
                              <div 
                                className={`stock-fill ${getStockLevel(product.quantity)}`}
                                style={{ width: `${Math.min((product.quantity / 100) * 100, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                        <td>
                          {getStatusBadge(product)}
                        </td>
                        <td>
                          <div className="action-buttons">
                            <Link 
                              to={`/product/${product._id}`} 
                              className="btn btn-sm btn-outline" 
                              title="View Product"
                            >
                              <FaEye />
                            </Link>
                            <Link 
                              to={`/admin/products/edit/${product._id}`} 
                              className="btn btn-sm btn-primary" 
                              title="Edit Product"
                            >
                              <FaEdit />
                            </Link>
                            <button 
                              onClick={() => handleToggleSold(product._id, product.isSold)}
                              className={`btn btn-sm ${product.isSold ? 'btn-success' : 'btn-warning'}`}
                              title={product.isSold ? 'Mark as Available' : 'Mark as Sold'}
                            >
                              {product.isSold ? <FaEyeSlash /> : <FaCheckCircle />}
                            </button>
                            <button 
                              onClick={() => handleDelete(product._id)} 
                              className="btn btn-sm btn-danger" 
                              title="Delete Product"
                            >
                              <FaTrash />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="pagination-container">
            <div className="pagination">
              <button 
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
                className="btn btn-outline"
              >
                Previous
              </button>
              <div className="page-info">
                Page {currentPage} of {totalPages}
              </div>
              <button 
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                disabled={currentPage === totalPages}
                className="btn btn-outline"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminProducts;
