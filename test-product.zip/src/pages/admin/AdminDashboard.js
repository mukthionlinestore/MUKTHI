import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../../config/axios';
import { 
  FaUsers, 
  FaShoppingCart, 
  FaBox, 
  FaDollarSign, 
  FaPlus, 
  FaEdit, 
  FaList, 
  FaChartLine,
  FaEye,
  FaArrowUp,
  FaArrowDown,
  FaClock,
  FaCheckCircle,
  FaExclamationTriangle,
  FaTruck,
  FaStar,
  FaCalendarAlt,
  FaBell,
  FaCog,
  FaSearch,
  FaFilter
} from 'react-icons/fa';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalOrders: 0,
    totalProducts: 0,
    totalRevenue: 0
  });
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('today');
  const [quickStats, setQuickStats] = useState({
    todayOrders: 0,
    todayRevenue: 0,
    lowStockProducts: 0,
    pendingOrders: 0
  });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [statsRes, ordersRes] = await Promise.all([
        axios.get('/api/admin/stats'),
        axios.get('/api/admin/recent-orders')
      ]);
      
      setStats(statsRes.data);
      setRecentOrders(ordersRes.data);
      
      // Calculate quick stats
      const today = new Date().toDateString();
      const todayOrders = ordersRes.data.filter(order => 
        new Date(order.createdAt).toDateString() === today
      );
      
      setQuickStats({
        todayOrders: todayOrders.length,
        todayRevenue: todayOrders.reduce((sum, order) => sum + order.total, 0),
        lowStockProducts: 0, // This would need a separate API call
        pendingOrders: ordersRes.data.filter(order => order.status === 'Pending').length
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'pending': return 'warning';
      case 'processing': return 'info';
      case 'shipped': return 'primary';
      case 'delivered': return 'success';
      case 'cancelled': return 'danger';
      default: return 'secondary';
    }
  };

  const getStatusIcon = (status) => {
    switch (status.toLowerCase()) {
      case 'pending': return <FaClock />;
      case 'processing': return <FaEdit />;
      case 'shipped': return <FaTruck />;
      case 'delivered': return <FaCheckCircle />;
      case 'cancelled': return <FaExclamationTriangle />;
      default: return <FaClock />;
    }
  };

  const getTrendIcon = (value) => {
    return value > 0 ? <FaArrowUp className="trend-up" /> : <FaArrowDown className="trend-down" />;
  };

  if (loading) {
    return (
      <div className="dashboard-page">
        <div className="container">
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading your dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <div className="container">
        {/* Modern Dashboard Header */}
        <div className="dashboard-header">
          <div className="header-content">
            <div className="welcome-section">
              <div className="welcome-badge">
                <FaBell className="notification-icon" />
                <span>Welcome back!</span>
              </div>
              <h1>Admin Dashboard</h1>
              <p>Monitor your store performance and manage everything from one place</p>
            </div>
            <div className="header-actions">
              <div className="period-selector">
                <FaCalendarAlt />
                <select 
                  value={selectedPeriod} 
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                  className="period-select"
                >
                  <option value="today">Today</option>
                  <option value="week">This Week</option>
                  <option value="month">This Month</option>
                  <option value="year">This Year</option>
                </select>
              </div>
              <button className="btn btn-outline btn-sm">
                <FaCog />
                Settings
              </button>
            </div>
          </div>
        </div>

        {/* Quick Stats Row */}
        <div className="quick-stats-row">
          <div className="quick-stat-card">
            <div className="quick-stat-icon">
              <FaShoppingCart />
            </div>
            <div className="quick-stat-content">
              <span className="quick-stat-label">Today's Orders</span>
              <span className="quick-stat-value">{quickStats.todayOrders}</span>
            </div>
          </div>
          
          <div className="quick-stat-card">
            <div className="quick-stat-icon">
              <FaDollarSign />
            </div>
            <div className="quick-stat-content">
              <span className="quick-stat-label">Today's Revenue</span>
              <span className="quick-stat-value">${quickStats.todayRevenue.toFixed(2)}</span>
            </div>
          </div>
          
          <div className="quick-stat-card">
            <div className="quick-stat-icon">
              <FaExclamationTriangle />
            </div>
            <div className="quick-stat-content">
              <span className="quick-stat-label">Pending Orders</span>
              <span className="quick-stat-value">{quickStats.pendingOrders}</span>
            </div>
          </div>
          
          <div className="quick-stat-card">
            <div className="quick-stat-icon">
              <FaBox />
            </div>
            <div className="quick-stat-content">
              <span className="quick-stat-label">Low Stock Items</span>
              <span className="quick-stat-value">{quickStats.lowStockProducts}</span>
            </div>
          </div>
        </div>

        {/* Main Stats Cards */}
        <div className="stats-grid">
          <div className="stat-card stat-card-users">
            <div className="stat-header">
              <div className="stat-icon">
                <FaUsers />
              </div>
              <div className="stat-trend">
                {getTrendIcon(12.5)}
                <span className="trend-value positive">+12.5%</span>
              </div>
            </div>
            <div className="stat-content">
              <h3 className="stat-number">{stats.totalUsers.toLocaleString()}</h3>
              <p className="stat-label">Total Users</p>
              <div className="stat-footer">
                <span className="stat-period">vs last month</span>
              </div>
            </div>
            <div className="stat-bg-pattern"></div>
          </div>

          <div className="stat-card stat-card-orders">
            <div className="stat-header">
              <div className="stat-icon">
                <FaShoppingCart />
              </div>
              <div className="stat-trend">
                {getTrendIcon(8.3)}
                <span className="trend-value positive">+8.3%</span>
              </div>
            </div>
            <div className="stat-content">
              <h3 className="stat-number">{stats.totalOrders.toLocaleString()}</h3>
              <p className="stat-label">Total Orders</p>
              <div className="stat-footer">
                <span className="stat-period">vs last month</span>
              </div>
            </div>
            <div className="stat-bg-pattern"></div>
          </div>

          <div className="stat-card stat-card-products">
            <div className="stat-header">
              <div className="stat-icon">
                <FaBox />
              </div>
              <div className="stat-trend">
                {getTrendIcon(15.2)}
                <span className="trend-value positive">+15.2%</span>
              </div>
            </div>
            <div className="stat-content">
              <h3 className="stat-number">{stats.totalProducts.toLocaleString()}</h3>
              <p className="stat-label">Total Products</p>
              <div className="stat-footer">
                <span className="stat-period">vs last month</span>
              </div>
            </div>
            <div className="stat-bg-pattern"></div>
          </div>

          <div className="stat-card stat-card-revenue">
            <div className="stat-header">
              <div className="stat-icon">
                <FaDollarSign />
              </div>
              <div className="stat-trend">
                {getTrendIcon(23.1)}
                <span className="trend-value positive">+23.1%</span>
              </div>
            </div>
            <div className="stat-content">
              <h3 className="stat-number">${stats.totalRevenue.toLocaleString()}</h3>
              <p className="stat-label">Total Revenue</p>
              <div className="stat-footer">
                <span className="stat-period">vs last month</span>
              </div>
            </div>
            <div className="stat-bg-pattern"></div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="dashboard-section">
          <div className="section-header">
            <h2>Quick Actions</h2>
            <p>Manage your store efficiently with these shortcuts</p>
          </div>
          <div className="actions-grid">
            <Link to="/admin/products/add" className="action-card action-card-primary">
              <div className="action-icon">
                <FaPlus />
              </div>
              <div className="action-content">
                <h3>Add Product</h3>
                <p>Create a new product listing with images and details</p>
              </div>
              <div className="action-arrow">→</div>
            </Link>

            <Link to="/admin/products" className="action-card action-card-secondary">
              <div className="action-icon">
                <FaList />
              </div>
              <div className="action-content">
                <h3>Manage Products</h3>
                <p>View, edit, and organize all your products</p>
              </div>
              <div className="action-arrow">→</div>
            </Link>

            <Link to="/admin/orders" className="action-card action-card-success">
              <div className="action-icon">
                <FaShoppingCart />
              </div>
              <div className="action-content">
                <h3>View Orders</h3>
                <p>Track and manage customer orders and shipments</p>
              </div>
              <div className="action-arrow">→</div>
            </Link>

            <Link to="/admin/users" className="action-card action-card-info">
              <div className="action-icon">
                <FaUsers />
              </div>
              <div className="action-content">
                <h3>Manage Users</h3>
                <p>View and manage user accounts and permissions</p>
              </div>
              <div className="action-arrow">→</div>
            </Link>

            <Link to="/admin/categories" className="action-card action-card-warning">
              <div className="action-icon">
                <FaList />
              </div>
              <div className="action-content">
                <h3>Manage Categories</h3>
                <p>Organize products with categories and subcategories</p>
              </div>
              <div className="action-arrow">→</div>
            </Link>

            <Link to="/admin/brands" className="action-card action-card-danger">
              <div className="action-icon">
                <FaStar />
              </div>
              <div className="action-content">
                <h3>Manage Brands</h3>
                <p>Add and manage product brands and manufacturers</p>
              </div>
              <div className="action-arrow">→</div>
            </Link>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="dashboard-section">
          <div className="section-header">
            <h2>Recent Orders</h2>
            <Link to="/admin/orders" className="view-all-link">View All Orders →</Link>
          </div>
          <div className="orders-card">
            <div className="orders-table">
              <table>
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {recentOrders.length > 0 ? (
                    recentOrders.map((order) => (
                      <tr key={order._id}>
                        <td>
                          <span className="order-id">#{order._id.slice(-6)}</span>
                        </td>
                        <td>
                          <div className="customer-info">
                            <span className="customer-name">{order.user?.name || 'Unknown'}</span>
                            <span className="customer-email">{order.user?.email || 'No email'}</span>
                          </div>
                        </td>
                        <td>
                          <span className="order-amount">${order.total.toFixed(2)}</span>
                        </td>
                        <td>
                          <span className={`status-badge status-${getStatusColor(order.status)}`}>
                            {getStatusIcon(order.status)}
                            {order.status}
                          </span>
                        </td>
                        <td>
                          <span className="order-date">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </span>
                        </td>
                        <td>
                          <Link to={`/admin/orders/${order._id}`} className="btn btn-sm btn-outline">
                            <FaEye /> View
                          </Link>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="6" className="no-orders">
                        <div className="no-data">
                          <FaShoppingCart />
                          <p>No orders yet</p>
                          <span>Orders will appear here once customers start shopping</span>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
