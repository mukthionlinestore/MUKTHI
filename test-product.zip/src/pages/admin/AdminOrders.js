import React, { useState, useEffect } from 'react';
import axios from '../../config/axios';
import { 
  FaEye, 
  FaEdit, 
  FaTrash, 
  FaSearch, 
  FaFilter, 
  FaDownload, 
  FaCheck, 
  FaTimes,
  FaTruck,
  FaBox,
  FaCheckCircle,
  FaExclamationTriangle,
  FaClock,
  FaUndo,
  FaPrint,
  FaEnvelope,
  FaPhone,
  FaMapMarkerAlt,
  FaCreditCard,
  FaMoneyBillWave,
  FaCalendarAlt,
  FaUser,
  FaShoppingCart,
  FaDollarSign,
  FaSort,
  FaSortUp,
  FaSortDown
} from 'react-icons/fa';
import { toast } from 'react-toastify';

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrders, setSelectedOrders] = useState([]);
  const [filters, setFilters] = useState({
    status: '',
    search: '',
    dateFrom: '',
    dateTo: ''
  });
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    total: 0,
    limit: 10
  });
  const [sortConfig, setSortConfig] = useState({
    field: 'createdAt',
    direction: 'desc'
  });
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [statusUpdate, setStatusUpdate] = useState({
    status: '',
    trackingNumber: '',
    notes: ''
  });

  useEffect(() => {
    fetchOrders();
  }, [filters, pagination.currentPage, sortConfig]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: pagination.currentPage,
        limit: pagination.limit,
        ...filters,
        sortBy: sortConfig.field,
        sortOrder: sortConfig.direction
      });

      const response = await axios.get(`/api/admin/orders?${params}`);
      setOrders(response.data.orders);
      setPagination(prev => ({
        ...prev,
        totalPages: response.data.totalPages,
        total: response.data.total
      }));
    } catch (error) {
      toast.error('Failed to load orders');
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async () => {
    try {
      if (selectedOrders.length === 0) {
        toast.error('Please select orders to update');
        return;
      }

      const response = await axios.put('/api/admin/orders/bulk/status', {
        orderIds: selectedOrders,
        ...statusUpdate
      });

      toast.success(response.data.message);
      setSelectedOrders([]);
      setShowStatusModal(false);
      setStatusUpdate({ status: '', trackingNumber: '', notes: '' });
      fetchOrders();
    } catch (error) {
      toast.error('Failed to update order status');
      console.error('Error updating order status:', error);
    }
  };

  const handleSingleStatusUpdate = async (orderId) => {
    try {
      const response = await axios.put(`/api/admin/orders/${orderId}/status`, statusUpdate);
      toast.success('Order status updated successfully');
      setShowStatusModal(false);
      setStatusUpdate({ status: '', trackingNumber: '', notes: '' });
      fetchOrders();
    } catch (error) {
      toast.error('Failed to update order status');
      console.error('Error updating order status:', error);
    }
  };

  const handlePaymentUpdate = async (orderId, isPaid) => {
    try {
      const response = await axios.put(`/api/admin/orders/${orderId}/payment`, { isPaid });
      toast.success('Payment status updated successfully');
      fetchOrders();
    } catch (error) {
      toast.error('Failed to update payment status');
      console.error('Error updating payment status:', error);
    }
  };

  const handleDeleteOrder = async (orderId) => {
    if (!window.confirm('Are you sure you want to delete this order? This action cannot be undone.')) {
      return;
    }

    try {
      await axios.delete(`/api/admin/orders/${orderId}`);
      toast.success('Order deleted successfully');
      fetchOrders();
    } catch (error) {
      toast.error('Failed to delete order');
      console.error('Error deleting order:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending': return 'warning';
      case 'processing': return 'info';
      case 'shipped': return 'primary';
      case 'delivered': return 'success';
      case 'cancelled': return 'danger';
      case 'returned': return 'secondary';
      default: return 'light';
    }
  };

  const getStatusIcon = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending': return <FaClock />;
      case 'processing': return <FaBox />;
      case 'shipped': return <FaTruck />;
      case 'delivered': return <FaCheckCircle />;
      case 'cancelled': return <FaTimes />;
      case 'returned': return <FaUndo />;
      default: return <FaClock />;
    }
  };

  const handleSort = (field) => {
    setSortConfig(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleBulkSelect = (orderId) => {
    setSelectedOrders(prev => 
      prev.includes(orderId) 
        ? prev.filter(id => id !== orderId)
        : [...prev, orderId]
    );
  };

  const handleSelectAll = () => {
    if (selectedOrders.length === orders.length) {
      setSelectedOrders([]);
    } else {
      setSelectedOrders(orders.map(order => order._id));
    }
  };

  const exportOrders = () => {
    const csvContent = [
      ['Order ID', 'Customer', 'Email', 'Phone', 'Status', 'Total', 'Date', 'Payment Status'],
      ...orders.map(order => [
        order.orderNumber,
        order.user?.name || 'N/A',
        order.user?.email || 'N/A',
        order.shippingAddress?.phone || 'N/A',
        order.status,
        `$${order.total?.toFixed(2)}`,
        new Date(order.createdAt).toLocaleDateString(),
        order.isPaid ? 'Paid' : 'Unpaid'
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orders-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="admin-page">
        <div className="container">
          <div className="loading-spinner">Loading orders...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div className="container">
        <div className="page-header">
          <div className="header-content">
            <h1>Order Management</h1>
            <p>Manage and track customer orders</p>
          </div>
          <div className="header-actions">
            <button 
              className="btn btn-outline" 
              onClick={exportOrders}
              disabled={orders.length === 0}
            >
              <FaDownload /> Export CSV
            </button>
            <button 
              className="btn btn-primary" 
              onClick={() => setShowStatusModal(true)}
              disabled={selectedOrders.length === 0}
            >
              <FaEdit /> Update Status ({selectedOrders.length})
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="filters-section">
          <div className="filters-grid">
            <div className="filter-group">
              <label>Search</label>
              <div className="search-input">
                <FaSearch />
                <input
                  type="text"
                  placeholder="Search by order ID, customer name, or email..."
                  value={filters.search}
                  onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                />
              </div>
            </div>

            <div className="filter-group">
              <label>Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
              >
                <option value="">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="Processing">Processing</option>
                <option value="Shipped">Shipped</option>
                <option value="Delivered">Delivered</option>
                <option value="Cancelled">Cancelled</option>
                <option value="Returned">Returned</option>
              </select>
            </div>

            <div className="filter-group">
              <label>Date From</label>
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) => setFilters(prev => ({ ...prev, dateFrom: e.target.value }))}
              />
            </div>

            <div className="filter-group">
              <label>Date To</label>
              <input
                type="date"
                value={filters.dateTo}
                onChange={(e) => setFilters(prev => ({ ...prev, dateTo: e.target.value }))}
              />
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="orders-table-container">
          <table className="orders-table">
            <thead>
              <tr>
                <th>
                  <input
                    type="checkbox"
                    checked={selectedOrders.length === orders.length && orders.length > 0}
                    onChange={handleSelectAll}
                  />
                </th>
                <th onClick={() => handleSort('orderNumber')}>
                  Order ID
                  {sortConfig.field === 'orderNumber' && (
                    sortConfig.direction === 'asc' ? <FaSortUp /> : <FaSortDown />
                  )}
                </th>
                <th onClick={() => handleSort('user.name')}>
                  Customer
                  {sortConfig.field === 'user.name' && (
                    sortConfig.direction === 'asc' ? <FaSortUp /> : <FaSortDown />
                  )}
                </th>
                <th>Contact</th>
                <th onClick={() => handleSort('total')}>
                  Amount
                  {sortConfig.field === 'total' && (
                    sortConfig.direction === 'asc' ? <FaSortUp /> : <FaSortDown />
                  )}
                </th>
                <th onClick={() => handleSort('status')}>
                  Status
                  {sortConfig.field === 'status' && (
                    sortConfig.direction === 'asc' ? <FaSortUp /> : <FaSortDown />
                  )}
                </th>
                <th onClick={() => handleSort('createdAt')}>
                  Date
                  {sortConfig.field === 'createdAt' && (
                    sortConfig.direction === 'asc' ? <FaSortUp /> : <FaSortDown />
                  )}
                </th>
                <th>Payment</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order._id}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selectedOrders.includes(order._id)}
                      onChange={() => handleBulkSelect(order._id)}
                    />
                  </td>
                  <td>
                    <span className="order-id">#{order.orderNumber}</span>
                  </td>
                  <td>
                    <div className="customer-info">
                      <span className="customer-name">{order.user?.name || 'Unknown'}</span>
                      <span className="customer-email">{order.user?.email || 'No email'}</span>
                    </div>
                  </td>
                  <td>
                    <div className="contact-info">
                      <span className="phone">{order.shippingAddress?.phone || 'No phone'}</span>
                    </div>
                  </td>
                  <td>
                    <span className="order-amount">${order.total?.toFixed(2)}</span>
                  </td>
                  <td>
                    <span className={`status-badge status-${getStatusColor(order.status)}`}>
                      {getStatusIcon(order.status)}
                      {order.status}
                    </span>
                  </td>
                  <td>
                    <span className="order-date">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </span>
                  </td>
                  <td>
                    <span className={`payment-status ${order.isPaid ? 'paid' : 'unpaid'}`}>
                      {order.isPaid ? <FaCheckCircle /> : <FaExclamationTriangle />}
                      {order.isPaid ? 'Paid' : 'Unpaid'}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button 
                        className="btn btn-sm btn-outline" 
                        title="View Details"
                        onClick={() => {
                          setSelectedOrder(order);
                          setShowOrderModal(true);
                        }}
                      >
                        <FaEye />
                      </button>
                      <button 
                        className="btn btn-sm btn-primary" 
                        title="Update Status"
                        onClick={() => {
                          setSelectedOrder(order);
                          setStatusUpdate({ status: order.status, trackingNumber: order.trackingNumber || '', notes: order.notes || '' });
                          setShowStatusModal(true);
                        }}
                      >
                        <FaEdit />
                      </button>
                      <button 
                        className={`btn btn-sm ${order.isPaid ? 'btn-success' : 'btn-warning'}`}
                        title={order.isPaid ? 'Mark as Unpaid' : 'Mark as Paid'}
                        onClick={() => handlePaymentUpdate(order._id, !order.isPaid)}
                      >
                        {order.isPaid ? <FaCheckCircle /> : <FaMoneyBillWave />}
                      </button>
                      {order.status === 'Cancelled' && (
                        <button 
                          className="btn btn-sm btn-danger" 
                          title="Delete Order"
                          onClick={() => handleDeleteOrder(order._id)}
                        >
                          <FaTrash />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {orders.length === 0 && (
            <div className="no-data">
              <FaShoppingCart />
              <p>No orders found</p>
              <span>Orders will appear here once customers start shopping</span>
            </div>
          )}
        </div>

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="pagination">
            <button
              className="btn btn-outline"
              disabled={pagination.currentPage === 1}
              onClick={() => setPagination(prev => ({ ...prev, currentPage: prev.currentPage - 1 }))}
            >
              Previous
            </button>
            
            <span className="page-info">
              Page {pagination.currentPage} of {pagination.totalPages} 
              ({pagination.total} total orders)
            </span>
            
            <button
              className="btn btn-outline"
              disabled={pagination.currentPage === pagination.totalPages}
              onClick={() => setPagination(prev => ({ ...prev, currentPage: prev.currentPage + 1 }))}
            >
              Next
            </button>
          </div>
        )}
      </div>

      {/* Order Details Modal */}
      {showOrderModal && selectedOrder && (
        <OrderDetailsModal
          order={selectedOrder}
          onClose={() => {
            setShowOrderModal(false);
            setSelectedOrder(null);
          }}
          onStatusUpdate={handleSingleStatusUpdate}
          onPaymentUpdate={handlePaymentUpdate}
        />
      )}

      {/* Status Update Modal */}
      {showStatusModal && (
        <StatusUpdateModal
          order={selectedOrder}
          statusUpdate={statusUpdate}
          setStatusUpdate={setStatusUpdate}
          onClose={() => {
            setShowStatusModal(false);
            setSelectedOrder(null);
            setStatusUpdate({ status: '', trackingNumber: '', notes: '' });
          }}
          onSubmit={selectedOrder ? handleSingleStatusUpdate : handleStatusUpdate}
          isBulk={!selectedOrder}
          selectedCount={selectedOrders.length}
        />
      )}
    </div>
  );
};

// Order Details Modal Component
const OrderDetailsModal = ({ order, onClose, onStatusUpdate, onPaymentUpdate }) => {
  const [statusUpdate, setStatusUpdate] = useState({
    status: order.status,
    trackingNumber: order.trackingNumber || '',
    notes: order.notes || ''
  });

  const handleStatusSubmit = () => {
    onStatusUpdate(order._id);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Order Details - #{order.orderNumber}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        
        <div className="modal-body">
          <div className="order-details-grid">
            {/* Customer Information */}
            <div className="detail-section">
              <h3><FaUser /> Customer Information</h3>
              <div className="detail-item">
                <span className="label">Name:</span>
                <span>{order.user?.name || 'Unknown'}</span>
              </div>
              <div className="detail-item">
                <span className="label">Email:</span>
                <span>{order.user?.email || 'No email'}</span>
              </div>
              <div className="detail-item">
                <span className="label">Phone:</span>
                <span>{order.shippingAddress?.phone || 'No phone'}</span>
              </div>
            </div>

            {/* Shipping Address */}
            <div className="detail-section">
              <h3><FaMapMarkerAlt /> Shipping Address</h3>
              <div className="address-details">
                <p>{order.shippingAddress?.fullName}</p>
                <p>{order.shippingAddress?.street}</p>
                <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} {order.shippingAddress?.zipCode}</p>
                <p>{order.shippingAddress?.country}</p>
              </div>
            </div>

            {/* Order Information */}
            <div className="detail-section">
              <h3><FaShoppingCart /> Order Information</h3>
              <div className="detail-item">
                <span className="label">Status:</span>
                <span className={`status-badge status-${order.status?.toLowerCase()}`}>
                  {order.status}
                </span>
              </div>
              <div className="detail-item">
                <span className="label">Payment Method:</span>
                <span>{order.paymentMethod}</span>
              </div>
              <div className="detail-item">
                <span className="label">Payment Status:</span>
                <span className={order.isPaid ? 'paid' : 'unpaid'}>
                  {order.isPaid ? 'Paid' : 'Unpaid'}
                </span>
              </div>
              <div className="detail-item">
                <span className="label">Order Date:</span>
                <span>{new Date(order.createdAt).toLocaleString()}</span>
              </div>
              {order.trackingNumber && (
                <div className="detail-item">
                  <span className="label">Tracking Number:</span>
                  <span>{order.trackingNumber}</span>
                </div>
              )}
            </div>

            {/* Order Items */}
            <div className="detail-section full-width">
              <h3><FaBox /> Order Items</h3>
              <div className="order-items">
                {order.items.map((item, index) => (
                  <div key={index} className="order-item">
                    <div className="item-image">
                      <img src={item.product?.images?.[0]} alt={item.product?.name} />
                    </div>
                    <div className="item-details">
                      <h4>{item.product?.name}</h4>
                      <p className="item-brand">{item.product?.brand}</p>
                      {item.selectedColor && (
                        <p className="item-variant">Color: {item.selectedColor.name}</p>
                      )}
                      {item.selectedSize && (
                        <p className="item-variant">Size: {item.selectedSize}</p>
                      )}
                      <p className="item-quantity">Quantity: {item.quantity}</p>
                      <p className="item-price">${item.price?.toFixed(2)} each</p>
                    </div>
                    <div className="item-total">
                      ${(item.price * item.quantity).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="detail-section">
              <h3><FaDollarSign /> Order Summary</h3>
              <div className="summary-item">
                <span>Subtotal:</span>
                <span>${order.subtotal?.toFixed(2)}</span>
              </div>
              <div className="summary-item">
                <span>Shipping:</span>
                <span>{order.shippingCost === 0 ? 'Free' : `$${order.shippingCost?.toFixed(2)}`}</span>
              </div>
              <div className="summary-item">
                <span>Tax:</span>
                <span>${order.tax?.toFixed(2)}</span>
              </div>
              <div className="summary-item total">
                <span>Total:</span>
                <span>${order.total?.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-outline" onClick={onClose}>Close</button>
          <button 
            className={`btn ${order.isPaid ? 'btn-warning' : 'btn-success'}`}
            onClick={() => onPaymentUpdate(order._id, !order.isPaid)}
          >
            {order.isPaid ? 'Mark as Unpaid' : 'Mark as Paid'}
          </button>
        </div>
      </div>
    </div>
  );
};

// Status Update Modal Component
const StatusUpdateModal = ({ order, statusUpdate, setStatusUpdate, onClose, onSubmit, isBulk, selectedCount }) => {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{isBulk ? `Update ${selectedCount} Orders` : 'Update Order Status'}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        
        <div className="modal-body">
          <div className="form-group">
            <label>Status</label>
            <select
              value={statusUpdate.status}
              onChange={(e) => setStatusUpdate(prev => ({ ...prev, status: e.target.value }))}
            >
              <option value="Pending">Pending</option>
              <option value="Processing">Processing</option>
              <option value="Shipped">Shipped</option>
              <option value="Delivered">Delivered</option>
              <option value="Cancelled">Cancelled</option>
              <option value="Returned">Returned</option>
            </select>
          </div>

          <div className="form-group">
            <label>Tracking Number (optional)</label>
            <input
              type="text"
              value={statusUpdate.trackingNumber}
              onChange={(e) => setStatusUpdate(prev => ({ ...prev, trackingNumber: e.target.value }))}
              placeholder="Enter tracking number"
            />
          </div>

          <div className="form-group">
            <label>Notes (optional)</label>
            <textarea
              value={statusUpdate.notes}
              onChange={(e) => setStatusUpdate(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Add any notes about this order"
              rows="3"
            />
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-outline" onClick={onClose}>Cancel</button>
          <button 
            className="btn btn-primary" 
            onClick={() => onSubmit(order?._id)}
            disabled={!statusUpdate.status}
          >
            Update Status
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminOrders;
