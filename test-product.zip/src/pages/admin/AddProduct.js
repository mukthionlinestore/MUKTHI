import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../../config/axios';
import { FaUpload, FaPlus, FaTrash, FaStar, FaSave, FaCloudUploadAlt } from 'react-icons/fa';
import { toast } from 'react-toastify';

const AddProduct = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [imageUploading, setImageUploading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    originalPrice: '',
    quantity: '',
    category: '',
    brand: '',
    sku: '',
    isNew: false,
    isSold: false,
    images: [],
    thumbnailIndex: 0,
    sizes: [],
    colors: [],
    features: []
  });
  const [newSize, setNewSize] = useState('');
  const [newColor, setNewColor] = useState({ name: '', code: '#000000' });
  const [newFeature, setNewFeature] = useState('');

  useEffect(() => {
    fetchCategories();
    fetchBrands();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/products/categories/list');
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchBrands = async () => {
    try {
      const response = await axios.get('/api/products/brands/list');
      setBrands(response.data);
    } catch (error) {
      console.error('Error fetching brands:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    
    if (files.length === 0) return;
    
    setImageUploading(true);
    
    try {
      // Convert files to base64
      const imagePromises = files.map(file => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target.result);
          reader.readAsDataURL(file);
        });
      });

      const base64Images = await Promise.all(imagePromises);
      
      // Upload to Cloudinary via backend
      const response = await axios.post('/api/upload/base64-images', {
        images: base64Images
      });

      const cloudinaryUrls = response.data.images.map(img => img.url);
      
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...cloudinaryUrls]
      }));
      
      toast.success(`${files.length} image(s) uploaded successfully!`);
    } catch (error) {
      console.error('Image upload error:', error);
      toast.error('Failed to upload images. Please try again.');
    } finally {
      setImageUploading(false);
    }
  };

  const removeImage = async (index) => {
    const imageUrl = formData.images[index];
    
    try {
      // Delete from Cloudinary if it's a Cloudinary URL
      if (imageUrl && imageUrl.includes('cloudinary.com')) {
        await axios.delete('/api/upload/images', {
          data: { url: imageUrl }
        });
      }
      
      setFormData(prev => ({
        ...prev,
        images: prev.images.filter((_, i) => i !== index),
        thumbnailIndex: prev.thumbnailIndex >= index ? Math.max(0, prev.thumbnailIndex - 1) : prev.thumbnailIndex
      }));
      
      toast.success('Image removed successfully!');
    } catch (error) {
      console.error('Error removing image:', error);
      toast.error('Failed to remove image. Please try again.');
    }
  };

  const setThumbnail = (index) => {
    setFormData(prev => ({
      ...prev,
      thumbnailIndex: index
    }));
  };

  const addSize = () => {
    if (newSize.trim() && !formData.sizes.some(s => s.name === newSize.trim())) {
      setFormData(prev => ({
        ...prev,
        sizes: [...prev.sizes, { name: newSize.trim(), available: true }]
      }));
      setNewSize('');
    }
  };

  const removeSize = (sizeName) => {
    setFormData(prev => ({
      ...prev,
      sizes: prev.sizes.filter(s => s.name !== sizeName)
    }));
  };

  const addColor = () => {
    if (newColor.name.trim() && !formData.colors.some(c => c.name === newColor.name.trim())) {
      setFormData(prev => ({
        ...prev,
        colors: [...prev.colors, { ...newColor, name: newColor.name.trim() }]
      }));
      setNewColor({ name: '', code: '#000000' });
    }
  };

  const removeColor = (colorName) => {
    setFormData(prev => ({
      ...prev,
      colors: prev.colors.filter(c => c.name !== colorName)
    }));
  };

  const addFeature = () => {
    if (newFeature.trim() && !formData.features.includes(newFeature.trim())) {
      setFormData(prev => ({
        ...prev,
        features: [...prev.features, newFeature.trim()]
      }));
      setNewFeature('');
    }
  };

  const removeFeature = (feature) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.filter(f => f !== feature)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.description || !formData.price || !formData.category || formData.images.length === 0) {
      toast.error('Please fill in all required fields (name, description, price, category) and upload at least one image');
      return;
    }

    setLoading(true);
    try {
      const productData = {
        ...formData,
        price: parseFloat(formData.price),
        originalPrice: formData.originalPrice ? parseFloat(formData.originalPrice) : null,
        quantity: formData.quantity ? parseInt(formData.quantity) : 0,
        sku: formData.sku.trim() || undefined // Only send if not empty
      };

      await axios.post('/api/admin/products', productData);
      toast.success('Product added successfully!');
      navigate('/admin/products');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to add product');
    } finally {
      setLoading(false);
    }
  };

  const styles = {
    adminPage: {
      minHeight: '100vh',
      backgroundColor: '#f8fafc',
      padding: '20px 0'
    },
    container: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '0 20px'
    },
    pageHeader: {
      textAlign: 'center',
      marginBottom: '40px',
      padding: '30px 20px',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      borderRadius: '20px',
      color: 'white',
      boxShadow: '0 10px 30px rgba(102, 126, 234, 0.3)'
    },
    pageTitle: {
      fontSize: '2.5rem',
      fontWeight: 'bold',
      margin: '0 0 10px 0',
      textShadow: '0 2px 4px rgba(0,0,0,0.1)'
    },
    pageSubtitle: {
      fontSize: '1.1rem',
      opacity: 0.9,
      margin: 0
    },
    productForm: {
      background: 'white',
      borderRadius: '20px',
      padding: '30px',
      boxShadow: '0 5px 20px rgba(0,0,0,0.08)',
      border: '1px solid #e2e8f0'
    },
    formGrid: {
      display: 'grid',
      gap: '30px'
    },
    formSection: {
      background: '#f8fafc',
      borderRadius: '16px',
      padding: '25px',
      border: '1px solid #e2e8f0'
    },
    sectionTitle: {
      fontSize: '1.4rem',
      fontWeight: '600',
      color: '#1e293b',
      marginBottom: '20px',
      paddingBottom: '10px',
      borderBottom: '2px solid #e2e8f0'
    },
    formGroup: {
      marginBottom: '20px'
    },
    formRow: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '20px',
      marginBottom: '20px'
    },
    label: {
      display: 'block',
      fontSize: '14px',
      fontWeight: '600',
      color: '#374151',
      marginBottom: '8px'
    },
    formControl: {
      width: '100%',
      padding: '12px 16px',
      fontSize: '14px',
      border: '2px solid #e2e8f0',
      borderRadius: '12px',
      backgroundColor: 'white',
      transition: 'all 0.2s ease',
      fontFamily: 'inherit'
    },
    formControlFocus: {
      borderColor: '#667eea',
      outline: 'none',
      boxShadow: '0 0 0 3px rgba(102, 126, 234, 0.1)'
    },
    textarea: {
      resize: 'vertical',
      minHeight: '100px'
    },
    checkboxGroup: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
      cursor: 'pointer',
      padding: '12px',
      backgroundColor: 'white',
      borderRadius: '12px',
      border: '2px solid #e2e8f0',
      transition: 'all 0.2s ease'
    },
    checkboxGroupHover: {
      borderColor: '#667eea',
      backgroundColor: '#f8fafc'
    },
    checkbox: {
      width: '18px',
      height: '18px',
      cursor: 'pointer'
    },
    uploadLabel: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '12px',
      padding: '40px 20px',
      border: '2px dashed #cbd5e1',
      borderRadius: '16px',
      backgroundColor: '#f8fafc',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      color: '#64748b'
    },
    uploadLabelHover: {
      borderColor: '#667eea',
      backgroundColor: '#f1f5f9',
      color: '#667eea'
    },
    uploadIcon: {
      fontSize: '2rem'
    },
    uploadText: {
      fontSize: '16px',
      fontWeight: '600'
    },
    hiddenInput: {
      display: 'none'
    },
    imagePreview: {
      marginTop: '25px'
    },
    imageGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
      gap: '20px',
      marginTop: '15px'
    },
    imageItem: {
      position: 'relative',
      borderRadius: '12px',
      overflow: 'hidden',
      backgroundColor: 'white',
      border: '2px solid #e2e8f0',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
    },
    imageItemImg: {
      width: '100%',
      height: '200px',
      objectFit: 'cover'
    },
    imageActions: {
      padding: '15px',
      display: 'flex',
      flexDirection: 'column',
      gap: '8px'
    },
    thumbnailBadge: {
      display: 'flex',
      alignItems: 'center',
      gap: '5px',
      fontSize: '12px',
      fontWeight: 'bold',
      color: '#f59e0b',
      marginBottom: '8px'
    },
    btn: {
      padding: '10px 20px',
      fontSize: '14px',
      fontWeight: '600',
      border: 'none',
      borderRadius: '8px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px'
    },
    btnPrimary: {
      backgroundColor: '#667eea',
      color: 'white'
    },
    btnPrimaryHover: {
      backgroundColor: '#5a67d8',
      transform: 'translateY(-1px)',
      boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)'
    },
    btnOutline: {
      backgroundColor: 'transparent',
      color: '#667eea',
      border: '2px solid #667eea'
    },
    btnOutlineHover: {
      backgroundColor: '#667eea',
      color: 'white'
    },
    btnDanger: {
      backgroundColor: '#ef4444',
      color: 'white'
    },
    btnDangerHover: {
      backgroundColor: '#dc2626'
    },
    btnSm: {
      padding: '6px 12px',
      fontSize: '12px'
    },
    inputGroup: {
      display: 'flex',
      gap: '12px',
      alignItems: 'center'
    },
    colorPicker: {
      width: '50px',
      height: '44px',
      padding: '0',
      border: '2px solid #e2e8f0',
      borderRadius: '8px',
      cursor: 'pointer'
    },
    tagContainer: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px',
      marginTop: '15px'
    },
    tag: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '8px 12px',
      backgroundColor: '#e0e7ff',
      color: '#3730a3',
      borderRadius: '20px',
      fontSize: '14px',
      fontWeight: '500'
    },
    colorTag: {
      paddingLeft: '8px'
    },
    colorSwatch: {
      width: '16px',
      height: '16px',
      borderRadius: '50%',
      border: '2px solid white',
      boxShadow: '0 0 0 1px #cbd5e1'
    },
    tagRemove: {
      background: 'none',
      border: 'none',
      fontSize: '16px',
      color: '#64748b',
      cursor: 'pointer',
      padding: '2px',
      borderRadius: '50%',
      width: '20px',
      height: '20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    },
    tagRemoveHover: {
      backgroundColor: '#f1f5f9',
      color: '#ef4444'
    },
    featureList: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px',
      marginTop: '15px'
    },
    featureItem: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '12px 16px',
      backgroundColor: 'white',
      borderRadius: '8px',
      border: '1px solid #e2e8f0'
    },
    formActions: {
      display: 'flex',
      gap: '15px',
      justifyContent: 'center',
      marginTop: '40px',
      padding: '30px 0'
    },
    // Mobile styles
    mobileFormRow: {
      gridTemplateColumns: '1fr',
      gap: '15px'
    },
    mobileImageGrid: {
      gridTemplateColumns: '1fr',
      gap: '15px'
    },
    mobileFormActions: {
      flexDirection: 'column',
      gap: '12px'
    },
    mobileBtn: {
      width: '100%',
      padding: '15px'
    }
  };

  const isMobile = window.innerWidth <= 768;

  return (
    <div style={styles.adminPage}>
      <div style={styles.container}>
        <div style={styles.pageHeader}>
          <h1 style={styles.pageTitle}>Add New Product</h1>
          <p style={styles.pageSubtitle}>Create a new product listing with all details</p>
        </div>

        <form onSubmit={handleSubmit} style={styles.productForm}>
          <div style={styles.formGrid}>
            {/* Basic Information */}
            <div style={styles.formSection}>
              <h3 style={styles.sectionTitle}>Basic Information</h3>
              
              <div style={styles.formGroup}>
                <label htmlFor="name" style={styles.label}>Product Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  style={styles.formControl}
                  onFocus={(e) => Object.assign(e.target.style, styles.formControlFocus)}
                  onBlur={(e) => Object.assign(e.target.style, styles.formControl)}
                  required
                />
              </div>

              <div style={styles.formGroup}>
                <label htmlFor="description" style={styles.label}>Description</label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  style={{...styles.formControl, ...styles.textarea}}
                  onFocus={(e) => Object.assign(e.target.style, {...styles.formControl, ...styles.textarea, ...styles.formControlFocus})}
                  onBlur={(e) => Object.assign(e.target.style, {...styles.formControl, ...styles.textarea})}
                  rows="4"
                />
              </div>

              <div style={isMobile ? styles.mobileFormRow : styles.formRow}>
                <div style={styles.formGroup}>
                  <label htmlFor="price" style={styles.label}>Price *</label>
                  <input
                    type="number"
                    id="price"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    style={styles.formControl}
                    onFocus={(e) => Object.assign(e.target.style, styles.formControlFocus)}
                    onBlur={(e) => Object.assign(e.target.style, styles.formControl)}
                    min="0"
                    step="0.01"
                    required
                  />
                </div>

                <div style={styles.formGroup}>
                  <label htmlFor="originalPrice" style={styles.label}>Original Price</label>
                  <input
                    type="number"
                    id="originalPrice"
                    name="originalPrice"
                    value={formData.originalPrice}
                    onChange={handleInputChange}
                    style={styles.formControl}
                    onFocus={(e) => Object.assign(e.target.style, styles.formControlFocus)}
                    onBlur={(e) => Object.assign(e.target.style, styles.formControl)}
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              <div style={isMobile ? styles.mobileFormRow : styles.formRow}>
                <div style={styles.formGroup}>
                  <label htmlFor="quantity" style={styles.label}>Quantity *</label>
                  <input
                    type="number"
                    id="quantity"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInputChange}
                    style={styles.formControl}
                    onFocus={(e) => Object.assign(e.target.style, styles.formControlFocus)}
                    onBlur={(e) => Object.assign(e.target.style, styles.formControl)}
                    min="0"
                    required
                  />
                </div>

                <div style={styles.formGroup}>
                  <label htmlFor="category" style={styles.label}>Category *</label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    style={styles.formControl}
                    onFocus={(e) => Object.assign(e.target.style, styles.formControlFocus)}
                    onBlur={(e) => Object.assign(e.target.style, styles.formControl)}
                    required
                  >
                    <option value="">Select Category</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
              </div>

                             <div style={styles.formGroup}>
                 <label htmlFor="brand" style={styles.label}>Brand</label>
                 <select
                   id="brand"
                   name="brand"
                   value={formData.brand}
                   onChange={handleInputChange}
                   style={styles.formControl}
                   onFocus={(e) => Object.assign(e.target.style, styles.formControlFocus)}
                   onBlur={(e) => Object.assign(e.target.style, styles.formControl)}
                 >
                   <option value="">Select Brand</option>
                   {brands.map(brand => (
                     <option key={brand} value={brand}>{brand}</option>
                   ))}
                 </select>
               </div>

               <div style={styles.formGroup}>
                 <label htmlFor="sku" style={styles.label}>SKU (Stock Keeping Unit)</label>
                 <input
                   type="text"
                   id="sku"
                   name="sku"
                   value={formData.sku}
                   onChange={handleInputChange}
                   style={styles.formControl}
                   onFocus={(e) => Object.assign(e.target.style, styles.formControlFocus)}
                   onBlur={(e) => Object.assign(e.target.style, styles.formControl)}
                   placeholder="Leave empty for auto-generation"
                 />
                 <small style={{ color: '#64748b', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                   Leave empty to auto-generate a unique SKU
                 </small>
               </div>

              <div style={isMobile ? styles.mobileFormRow : styles.formRow}>
                <label 
                  style={styles.checkboxGroup}
                  onMouseEnter={(e) => Object.assign(e.target.style, {...styles.checkboxGroup, ...styles.checkboxGroupHover})}
                  onMouseLeave={(e) => Object.assign(e.target.style, styles.checkboxGroup)}
                >
                  <input
                    type="checkbox"
                    name="isNew"
                    checked={formData.isNew}
                    onChange={handleInputChange}
                    style={styles.checkbox}
                  />
                  Mark as New Product
                </label>

                <label 
                  style={styles.checkboxGroup}
                  onMouseEnter={(e) => Object.assign(e.target.style, {...styles.checkboxGroup, ...styles.checkboxGroupHover})}
                  onMouseLeave={(e) => Object.assign(e.target.style, styles.checkboxGroup)}
                >
                  <input
                    type="checkbox"
                    name="isSold"
                    checked={formData.isSold}
                    onChange={handleInputChange}
                    style={styles.checkbox}
                  />
                  Mark as Sold
                </label>
              </div>
            </div>

            {/* Images */}
            <div style={styles.formSection}>
              <h3 style={styles.sectionTitle}>Product Images</h3>
              
              <div>
                <label 
                  htmlFor="images" 
                  style={styles.uploadLabel}
                  onMouseEnter={(e) => Object.assign(e.target.style, {...styles.uploadLabel, ...styles.uploadLabelHover})}
                  onMouseLeave={(e) => Object.assign(e.target.style, styles.uploadLabel)}
                >
                  <FaUpload style={styles.uploadIcon} />
                  <span style={styles.uploadText}>Upload Images</span>
                  <input
                    type="file"
                    id="images"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    style={styles.hiddenInput}
                    disabled={imageUploading}
                  />
                  {imageUploading && (
                    <p style={{ color: '#667eea', fontSize: '14px', marginTop: '10px' }}>
                      <FaCloudUploadAlt /> Uploading images...
                    </p>
                  )}
                </label>
              </div>

              {formData.images.length > 0 && (
                <div style={styles.imagePreview}>
                  <h4 style={styles.sectionTitle}>Uploaded Images</h4>
                  <div style={isMobile ? styles.mobileImageGrid : styles.imageGrid}>
                    {formData.images.map((image, index) => (
                      <div key={index} style={styles.imageItem}>
                        <img src={image} alt={`Product ${index + 1}`} style={styles.imageItemImg} />
                        <div style={styles.imageActions}>
                          {index === formData.thumbnailIndex && (
                            <span style={styles.thumbnailBadge}>
                              <FaStar /> Thumbnail
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={() => setThumbnail(index)}
                            style={{...styles.btn, ...styles.btnOutline, ...styles.btnSm}}
                            onMouseEnter={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnOutline, ...styles.btnSm, ...styles.btnOutlineHover})}
                            onMouseLeave={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnOutline, ...styles.btnSm})}
                            disabled={index === formData.thumbnailIndex}
                          >
                            Set Thumbnail
                          </button>
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            style={{...styles.btn, ...styles.btnDanger, ...styles.btnSm}}
                            onMouseEnter={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnDanger, ...styles.btnSm, ...styles.btnDangerHover})}
                            onMouseLeave={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnDanger, ...styles.btnSm})}
                          >
                            <FaTrash />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sizes */}
            <div style={styles.formSection}>
              <h3 style={styles.sectionTitle}>Available Sizes</h3>
              
              <div style={styles.inputGroup}>
                <input
                  type="text"
                  value={newSize}
                  onChange={(e) => setNewSize(e.target.value)}
                  placeholder="Enter size (e.g., S, M, L, XL)"
                  style={{...styles.formControl, flex: 1}}
                  onFocus={(e) => Object.assign(e.target.style, {...styles.formControl, ...styles.formControlFocus, flex: 1})}
                  onBlur={(e) => Object.assign(e.target.style, {...styles.formControl, flex: 1})}
                />
                <button 
                  type="button" 
                  onClick={addSize} 
                  style={{...styles.btn, ...styles.btnPrimary}}
                  onMouseEnter={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnPrimary, ...styles.btnPrimaryHover})}
                  onMouseLeave={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnPrimary})}
                >
                  <FaPlus />
                </button>
              </div>

              {formData.sizes.length > 0 && (
                <div style={styles.tagContainer}>
                  {formData.sizes.map((size, index) => (
                    <span key={index} style={styles.tag}>
                      {size.name}
                      <button
                        type="button"
                        onClick={() => removeSize(size.name)}
                        style={styles.tagRemove}
                        onMouseEnter={(e) => Object.assign(e.target.style, {...styles.tagRemove, ...styles.tagRemoveHover})}
                        onMouseLeave={(e) => Object.assign(e.target.style, styles.tagRemove)}
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Colors */}
            <div style={styles.formSection}>
              <h3 style={styles.sectionTitle}>Available Colors</h3>
              
              <div style={styles.inputGroup}>
                <input
                  type="text"
                  value={newColor.name}
                  onChange={(e) => setNewColor(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Color name (e.g., Red, Blue)"
                  style={{...styles.formControl, flex: 1}}
                  onFocus={(e) => Object.assign(e.target.style, {...styles.formControl, ...styles.formControlFocus, flex: 1})}
                  onBlur={(e) => Object.assign(e.target.style, {...styles.formControl, flex: 1})}
                />
                <input
                  type="color"
                  value={newColor.code}
                  onChange={(e) => setNewColor(prev => ({ ...prev, code: e.target.value }))}
                  style={styles.colorPicker}
                />
                <button 
                  type="button" 
                  onClick={addColor} 
                  style={{...styles.btn, ...styles.btnPrimary}}
                  onMouseEnter={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnPrimary, ...styles.btnPrimaryHover})}
                  onMouseLeave={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnPrimary})}
                >
                  <FaPlus />
                </button>
              </div>

              {formData.colors.length > 0 && (
                <div style={styles.tagContainer}>
                  {formData.colors.map((color, index) => (
                    <span key={index} style={{...styles.tag, ...styles.colorTag}}>
                      <span
                        style={{...styles.colorSwatch, backgroundColor: color.code}}
                      ></span>
                      {color.name}
                      <button
                        type="button"
                        onClick={() => removeColor(color.name)}
                        style={styles.tagRemove}
                        onMouseEnter={(e) => Object.assign(e.target.style, {...styles.tagRemove, ...styles.tagRemoveHover})}
                        onMouseLeave={(e) => Object.assign(e.target.style, styles.tagRemove)}
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Features */}
            <div style={styles.formSection}>
              <h3 style={styles.sectionTitle}>Product Features</h3>
              
              <div style={styles.inputGroup}>
                <input
                  type="text"
                  value={newFeature}
                  onChange={(e) => setNewFeature(e.target.value)}
                  placeholder="Enter feature"
                  style={{...styles.formControl, flex: 1}}
                  onFocus={(e) => Object.assign(e.target.style, {...styles.formControl, ...styles.formControlFocus, flex: 1})}
                  onBlur={(e) => Object.assign(e.target.style, {...styles.formControl, flex: 1})}
                />
                <button 
                  type="button" 
                  onClick={addFeature} 
                  style={{...styles.btn, ...styles.btnPrimary}}
                  onMouseEnter={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnPrimary, ...styles.btnPrimaryHover})}
                  onMouseLeave={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnPrimary})}
                >
                  <FaPlus />
                </button>
              </div>

              {formData.features.length > 0 && (
                <div style={styles.featureList}>
                  {formData.features.map((feature, index) => (
                    <div key={index} style={styles.featureItem}>
                      <span>{feature}</span>
                      <button
                        type="button"
                        onClick={() => removeFeature(feature)}
                        style={{...styles.btn, ...styles.btnDanger, ...styles.btnSm}}
                        onMouseEnter={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnDanger, ...styles.btnSm, ...styles.btnDangerHover})}
                        onMouseLeave={(e) => Object.assign(e.target.style, {...styles.btn, ...styles.btnDanger, ...styles.btnSm})}
                      >
                        <FaTrash />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div style={isMobile ? {...styles.formActions, ...styles.mobileFormActions} : styles.formActions}>
            <button
              type="button"
              onClick={() => navigate('/admin/products')}
              style={isMobile ? 
                {...styles.btn, ...styles.btnOutline, ...styles.mobileBtn} : 
                {...styles.btn, ...styles.btnOutline}
              }
              onMouseEnter={(e) => Object.assign(e.target.style, isMobile ? 
                {...styles.btn, ...styles.btnOutline, ...styles.mobileBtn, ...styles.btnOutlineHover} :
                {...styles.btn, ...styles.btnOutline, ...styles.btnOutlineHover}
              )}
              onMouseLeave={(e) => Object.assign(e.target.style, isMobile ? 
                {...styles.btn, ...styles.btnOutline, ...styles.mobileBtn} :
                {...styles.btn, ...styles.btnOutline}
              )}
            >
              Cancel
            </button>
            <button
              type="submit"
              style={isMobile ? 
                {...styles.btn, ...styles.btnPrimary, ...styles.mobileBtn} : 
                {...styles.btn, ...styles.btnPrimary}
              }
              onMouseEnter={(e) => !loading && Object.assign(e.target.style, isMobile ? 
                {...styles.btn, ...styles.btnPrimary, ...styles.mobileBtn, ...styles.btnPrimaryHover} :
                {...styles.btn, ...styles.btnPrimary, ...styles.btnPrimaryHover}
              )}
              onMouseLeave={(e) => Object.assign(e.target.style, isMobile ? 
                {...styles.btn, ...styles.btnPrimary, ...styles.mobileBtn} :
                {...styles.btn, ...styles.btnPrimary}
              )}
              disabled={loading}
            >
              {loading ? 'Adding Product...' : (
                <>
                  <FaSave />
                  Add Product
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddProduct;