import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import axios from '../config/axios';
import { useAuth } from '../context/AuthContext';
import { FaTrash, FaMinus, FaPlus, FaShoppingCart, FaArrowLeft, FaHeart, FaTimes, FaExclamationTriangle } from 'react-icons/fa';
import { toast } from 'react-toastify';

// --- Helpers ---
const useAbortableAxios = () => {
  const abortRef = useRef(null);
  useEffect(() => () => abortRef.current?.abort?.(), []);
  const withSignal = () => {
    abortRef.current?.abort?.();
    abortRef.current = new AbortController();
    return { signal: abortRef.current.signal };
  };
  return { withSignal };
};

const useDebounce = (delay = 350) => {
  const timers = useRef(new Map());
  const debounce = (key, fn) => {
    if (timers.current.has(key)) clearTimeout(timers.current.get(key));
    const t = setTimeout(fn, delay);
    timers.current.set(key, t);
  };
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  return debounce;
};

const Cart = () => {
  const { isAuthenticated } = useAuth();
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updatingItems, setUpdatingItems] = useState({});
  const [moving, setMoving] = useState({});
  const { withSignal } = useAbortableAxios();
  const debounce = useDebounce(350);

  useEffect(() => {
    const fetchCart = async () => {
      if (!isAuthenticated) { setLoading(false); return; }
      try {
        setLoading(true);
        const response = await axios.get('/api/cart', withSignal());
        setCart(response.data);
        
        // Show cleanup message if any
        if (response.data.message) {
          toast.info(response.data.message);
        }
      } catch (error) {
        if (error.name !== 'CanceledError') {
          console.error('Error fetching cart:', error);
          if (error.code === 'ERR_NETWORK') {
            toast.error('Network error - Please check if the server is running');
          } else if (error.response?.status === 401) {
            toast.error('Please log in to view your cart');
          } else {
            toast.error('Failed to load cart');
          }
        }
      } finally {
        setLoading(false);
      }
    };
    fetchCart();
  }, [isAuthenticated]);

  const updateQuantity = (itemId, nextQty) => {
    if (nextQty < 1) return;
    
    // Optimistic UI
    setCart((prev) => {
      if (!prev) return prev;
      const items = prev.items.map((it) => it._id === itemId ? { ...it, quantity: nextQty } : it);
      const total = items.reduce((s, it) => s + (it.price * it.quantity), 0);
      const totalItems = items.reduce((s, it) => s + it.quantity, 0);
      return { ...prev, items, total, totalItems };
    });

    setUpdatingItems((p) => ({ ...p, [itemId]: true }));

    // Debounced network call
    debounce(`qty-${itemId}`, async () => {
      try {
        const response = await axios.put(`/api/cart/update/${itemId}`, { quantity: nextQty });
        setCart(response.data);
        
        // Show cleanup message if any
        if (response.data.message) {
          toast.info(response.data.message);
        } else {
          toast.success('Cart updated');
        }
      } catch (error) {
        console.error('Error updating cart:', error);
        toast.error('Failed to update cart');
      } finally {
        setUpdatingItems((p) => ({ ...p, [itemId]: false }));
      }
    });
  };

  const removeItem = async (itemId) => {
    if (!window.confirm('Remove this item from your cart?')) return;
    try {
      const response = await axios.delete(`/api/cart/remove/${itemId}`);
      setCart(response.data);
      toast.success('Item removed');
    } catch (error) {
      console.error('Error removing item:', error);
      toast.error('Failed to remove item');
    }
  };

  const moveToWishlist = async (productId, itemId) => {
    if (moving[itemId]) return; // lock
    setMoving((p) => ({ ...p, [itemId]: true }));
    try {
      await axios.post('/api/wishlist/add', { productId });
      const response = await axios.delete(`/api/cart/remove/${itemId}`);
      setCart(response.data);
      toast.success('Moved to wishlist');
    } catch (error) {
      console.error('Error moving to wishlist:', error);
      toast.error('Failed to move item to wishlist');
    } finally {
      setMoving((p) => ({ ...p, [itemId]: false }));
    }
  };

  const clearCart = async () => {
    if (!window.confirm('Clear all items from your cart?')) return;
    try {
      const response = await axios.delete('/api/cart/clear');
      setCart(response.data);
      toast.success('Cart cleared');
    } catch (error) {
      console.error('Error clearing cart:', error);
      toast.error('Failed to clear cart');
    }
  };

  // Check if cart has any valid items
  const hasValidItems = cart?.items?.some(item => item.product && item.product.isActive !== false);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your cart...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <FaShoppingCart className="mx-auto h-12 w-12 text-gray-400" />
          <h2 className="mt-4 text-xl font-semibold text-gray-900">Please log in to view your cart</h2>
          <Link to="/login" className="mt-4 inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
            Log In
          </Link>
        </div>
      </div>
    );
  }

  if (!cart || !cart.items || cart.items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center">
            <FaShoppingCart className="mx-auto h-16 w-16 text-gray-400" />
            <h2 className="mt-4 text-2xl font-semibold text-gray-900">Your cart is empty</h2>
            <p className="mt-2 text-gray-600">Add some products to get started!</p>
            <Link to="/" className="mt-6 inline-block bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Filter out invalid items for display
  const validItems = cart.items.filter(item => item.product && item.product.isActive !== false);
  const invalidItems = cart.items.filter(item => !item.product || item.product.isActive === false);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-gray-600 hover:text-gray-900">
              <FaArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Shopping Cart</h1>
            <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
              {cart.totalItems} items
            </span>
          </div>
          {cart.items.length > 0 && (
            <button
              onClick={clearCart}
              className="text-red-600 hover:text-red-800 font-medium"
            >
              Clear Cart
            </button>
          )}
        </div>

        {/* Cart Items */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border">
              {/* Show invalid items first */}
              {invalidItems.map((item) => (
                <div key={item._id} className="p-6 border-b last:border-b-0">
                  <div className="flex items-center space-x-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <FaExclamationTriangle className="h-5 w-5 text-red-500 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-red-800 font-medium">Product No Longer Available</p>
                      <p className="text-red-600 text-sm">This product has been removed from our store.</p>
                    </div>
                    <button
                      onClick={() => removeItem(item._id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <FaTimes className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}

              {/* Show valid items */}
              {validItems.map((item) => (
                <div key={item._id} className="p-6 border-b last:border-b-0">
                  <div className="flex items-center space-x-4">
                    <img
                      src={item.product.images?.[0] || 'https://via.placeholder.com/80x80?text=No+Image'}
                      alt={item.product.name}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{item.product.name}</h3>
                      <p className="text-sm text-gray-500">{item.product.category}</p>
                      {item.selectedColor && (
                        <p className="text-sm text-gray-500">Color: {item.selectedColor.name}</p>
                      )}
                      {item.selectedSize && (
                        <p className="text-sm text-gray-500">Size: {item.selectedSize}</p>
                      )}
                      <p className="text-lg font-semibold text-gray-900">${item.price}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => updateQuantity(item._id, item.quantity - 1)}
                        disabled={updatingItems[item._id]}
                        className="p-1 rounded hover:bg-gray-100 disabled:opacity-50"
                      >
                        <FaMinus className="h-3 w-3" />
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item._id, item.quantity + 1)}
                        disabled={updatingItems[item._id]}
                        className="p-1 rounded hover:bg-gray-100 disabled:opacity-50"
                      >
                        <FaPlus className="h-3 w-3" />
                      </button>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => moveToWishlist(item.product._id, item._id)}
                        disabled={moving[item._id]}
                        className="p-2 text-gray-400 hover:text-red-500 disabled:opacity-50"
                        title="Move to wishlist"
                      >
                        <FaHeart className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => removeItem(item._id)}
                        className="p-2 text-gray-400 hover:text-red-500"
                        title="Remove item"
                      >
                        <FaTrash className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {/* Show message if no valid items */}
              {validItems.length === 0 && invalidItems.length === 0 && (
                <div className="p-6 text-center text-gray-500">
                  No items in cart
                </div>
              )}
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border p-6 sticky top-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h2>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal ({cart.totalItems} items)</span>
                  <span className="font-medium">${cart.total?.toFixed(2) || '0.00'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium">Free</span>
                </div>
                <div className="border-t pt-3">
                  <div className="flex justify-between">
                    <span className="text-lg font-semibold">Total</span>
                    <span className="text-lg font-semibold">${cart.total?.toFixed(2) || '0.00'}</span>
                  </div>
                </div>
              </div>

              {hasValidItems ? (
                <Link
                  to="/checkout"
                  className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 font-medium text-center block"
                >
                  Proceed to Checkout
                </Link>
              ) : (
                <div className="text-center text-gray-500 text-sm">
                  No valid items in cart
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
