import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { useWishlist } from "../context/WishlistContext";
import { useAuth } from "../context/AuthContext";
import SizeColorModal from "../components/products/SizeColorModal";

const sr = (n = 0) =>
  Array.from({ length: 5 }).map((_, i) => (
    <svg
      key={i}
      viewBox="0 0 24 24"
      className={`h-4 w-4 ${i < Math.floor(n) ? "fill-yellow-400" : "fill-gray-300"}`}
      aria-hidden="true"
    >
      <path d="M12 .587l3.668 7.431 8.2 1.192-5.934 5.787 1.402 8.17L12 18.896l-7.336 3.87 1.402-8.17L.132 9.21l8.2-1.192L12 .587z" />
    </svg>
  ));

const Pill = ({ children, tone = "default" }) => {
  const tones = {
    default: "bg-gray-100 text-gray-700 ring-1 ring-gray-200",
    new: "bg-gradient-to-r from-fuchsia-600 to-sky-500 text-white",
    sale: "bg-gradient-to-r from-rose-500 to-pink-500 text-white",
    low: "bg-gradient-to-r from-amber-500 to-red-500 text-white",
    sold: "bg-gray-600 text-white",
    save: "text-emerald-700 bg-emerald-50 ring-1 ring-emerald-200",
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${tones[tone]}`}>
      {children}
    </span>
  );
};

const TabButton = ({ active, onClick, children }) => (
  <button
    onClick={onClick}
    className={`whitespace-nowrap border-b-2 px-3 py-2 text-sm font-medium transition
      ${active ? "border-gray-900 text-gray-900" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`}
    type="button"
  >
    {children}
  </button>
);

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState(0);
  const [related, setRelated] = useState([]);
  const [toast, setToast] = useState(null);
  const [showSizeColorModal, setShowSizeColorModal] = useState(false);
  const [modalAction, setModalAction] = useState('cart'); // 'cart' or 'buy'

  const showToast = (msg, tone = "info") => {
    setToast({ msg, tone });
    setTimeout(() => setToast(null), 3500);
  };

  // Fetch product
  useEffect(() => {
    const run = async () => {
      try {
        setLoading(true);
        const res = await fetch(`/api/products/${id}`);
        if (!res.ok) throw new Error("Product not found");
        const data = await res.json();
        setProduct(data);
        if (data.thumbnailIndex != null) setSelectedImage(data.thumbnailIndex);
        fetchRelated(data.category, data._id);
      } catch (e) {
        showToast(e.message || "Failed to load product", "error");
      } finally {
        setLoading(false);
      }
    };
    if (id) run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const fetchRelated = async (category, currentId) => {
    try {
      const res = await fetch(`/api/products?category=${category}&limit=4`);
      if (res.ok) {
        const data = await res.json();
        const filtered = (data.products || []).filter((p) => p._id !== currentId).slice(0, 4);
        setRelated(filtered);
      }
    } catch {}
  };

  const discountPct =
    product?.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null;

  const handleAddToCart = async () => {
    if (!user) {
      showToast("Please login to add items to cart", "error");
      navigate("/login");
      return;
    }
    if (product.quantity <= 0) {
      showToast("Product is out of stock", "error");
      return;
    }
    
    // Check if product has colors or sizes that need selection
    const hasColors = product.colors && product.colors.length > 0;
    const hasSizes = product.sizes && product.sizes.length > 0;
    
    if (hasColors || hasSizes) {
      setModalAction('cart');
      setShowSizeColorModal(true);
      return;
    }
    
    // If no colors/sizes needed, add directly
    try {
      await addToCart(product, qty);
      showToast(`Added ${qty} item(s) to cart!`, "success");
    } catch {
      showToast("Failed to add to cart", "error");
    }
  };

  const toggleWishlist = async () => {
    if (!user) {
      showToast("Please login to manage wishlist", "error");
      navigate("/login");
      return;
    }
    try {
      if (isInWishlist(product._id)) {
        await removeFromWishlist(product._id);
        showToast("Removed from wishlist", "success");
      } else {
        await addToWishlist(product);
        showToast("Added to wishlist!", "success");
      }
    } catch {
      showToast("Failed to update wishlist", "error");
    }
  };

  const buyNow = async () => {
    if (!user) {
      showToast("Please login to continue", "error");
      navigate("/login");
      return;
    }
    if (product.quantity <= 0) {
      showToast("Product is out of stock", "error");
      return;
    }
    
    // Check if product has colors or sizes that need selection
    const hasColors = product.colors && product.colors.length > 0;
    const hasSizes = product.sizes && product.sizes.length > 0;
    
    if (hasColors || hasSizes) {
      setModalAction('buy');
      setShowSizeColorModal(true);
      return;
    }
    
    // If no colors/sizes needed, proceed with direct buy
    const directBuyItem = {
      product: product._id,
      quantity: qty,
      selectedColor: null,
      selectedSize: null,
      price: product.price
    };
    
    navigate("/checkout", { 
      state: { 
        directBuy: true, 
        directBuyItem: directBuyItem 
      } 
    });
  };

  const shareLink = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title: product.name, text: product.description, url });
      } catch (e) {}
    } else {
      try {
        await navigator.clipboard.writeText(url);
        showToast("Link copied to clipboard!", "success");
      } catch {
        showToast("Failed to copy link", "error");
      }
    }
  };

  const handleModalConfirm = async ({ product, quantity, selectedColor, selectedSize }) => {
    try {
      if (modalAction === 'buy') {
        // For direct buy, navigate to checkout with the item data
        const directBuyItem = {
          product: product._id,
          quantity: quantity,
          selectedColor: selectedColor,
          selectedSize: selectedSize,
          price: product.price
        };
        
        navigate("/checkout", { 
          state: { 
            directBuy: true, 
            directBuyItem: directBuyItem 
          } 
        });
      } else {
        // For cart, add to cart normally
        await addToCart(product, quantity, selectedColor, selectedSize);
        showToast(`Added ${quantity} item(s) to cart!`, "success");
      }
    } catch {
      showToast("Failed to process request", "error");
    }
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] grid place-items-center p-8">
        <div className="text-center">
          <div className="mx-auto mb-3 h-14 w-14 animate-spin rounded-full border-4 border-gray-200 border-t-gray-800" />
          <p className="text-gray-500">Loading product details…</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-[60vh] grid place-items-center p-6">
        <div className="max-w-md w-full rounded-2xl border border-gray-200 p-8 text-center shadow-soft">
          <div className="mx-auto mb-4 grid h-20 w-20 place-items-center rounded-full bg-gray-100 text-3xl text-gray-500">
            404
          </div>
          <h1 className="mb-2 text-2xl font-semibold">Product not found</h1>
          <p className="mb-6 text-gray-600">
            The product you're looking for doesn't exist or has been removed.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
            <button onClick={() => navigate("/")} className="btn-primary">Back to Home</button>
            <button onClick={() => navigate(-1)} className="btn-outline">Go Back</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top bar */}
      <header className="sticky top-0 z-20 border-b bg-white/80 backdrop-blur">
        <div className="mx-auto flex  items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate(-1)} className="rounded-full p-2 hover:bg-gray-100" aria-label="Go back">
              <svg viewBox="0 0 24 24" className="h-5 w-5"><path d="M15 6l-6 6 6 6" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
            </button>
            <nav className="hidden md:block text-sm">
              <ol className="flex items-center gap-2 text-gray-500">
                <li><Link to="/" className="hover:text-gray-900">Home</Link></li>
                <li className="text-gray-400">/</li>
                <li><Link to={`/?category=${product.category}`} className="hover:text-gray-900">{product.category}</Link></li>
                <li className="text-gray-400">/</li>
                <li className="truncate max-w-[220px]" title={product.name}>{product.name}</li>
              </ol>
            </nav>
          </div>
          <button onClick={shareLink} className="rounded-full p-2 hover:bg-gray-100" aria-label="Share">
            <svg viewBox="0 0 24 24" className="h-5 w-5"><path d="M4 12v7a1 1 0 001 1h14a1 1 0 001-1v-7M16 6l-4-4-4 4M12 2v14" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
          </button>
        </div>
      </header>

      <main className="mx-auto  px-4 py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          {/* Gallery */}
          <section className="md:sticky md:top-24">
            <div className="relative overflow-hidden rounded-2xl bg-gray-100 aspect-square">
              {product.images?.length ? (
                // eslint-disable-next-line jsx-a11y/img-redundant-alt
                <img
                  src={product.images[selectedImage] || product.images[0]}
                  alt={`Image ${selectedImage + 1} of ${product.name}`}
                  className="h-full w-full object-cover transition-transform duration-300 hover:scale-[1.02]"
                  onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/800x800?text=No+Image")}
                />
              ) : (
                <div className="grid h-full w-full place-items-center text-gray-500">No Image Available</div>
              )}

              {product.images?.length > 1 && (
                <>
                  <button
                    className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 shadow hover:bg-white"
                    onClick={() =>
                      setSelectedImage(selectedImage > 0 ? selectedImage - 1 : product.images.length - 1)
                    }
                    aria-label="Previous image"
                  >
                    <svg viewBox="0 0 24 24" className="h-5 w-5"><path d="M15 6l-6 6 6 6" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
                  </button>
                  <button
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 shadow hover:bg-white"
                    onClick={() =>
                      setSelectedImage(selectedImage < product.images.length - 1 ? selectedImage + 1 : 0)
                    }
                    aria-label="Next image"
                  >
                    <svg viewBox="0 0 24 24" className="h-5 w-5"><path d="M9 6l6 6-6 6" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
                  </button>
                </>
              )}

              {/* Badges */}
              <div className="absolute left-3 top-3 flex flex-col gap-2">
                {product.isNewProduct && <Pill tone="new">New</Pill>}
                {discountPct != null && <Pill tone="sale">-{discountPct}%</Pill>}
                {product.isSold && <Pill tone="sold">Sold</Pill>}
                {product.quantity <= 10 && product.quantity > 0 && <Pill tone="low">Low Stock</Pill>}
              </div>
            </div>

            {product.images?.length > 1 && (
              <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`h-20 w-20 flex-none overflow-hidden rounded-lg ring-2 transition
                      ${selectedImage === i ? "ring-gray-900" : "ring-gray-200 hover:ring-gray-300"}`}
                    aria-label={`Thumbnail ${i + 1}`}
                  >
                    {/* eslint-disable-next-line jsx-a11y/img-redundant-alt */}
                    <img
                      src={img}
                      alt={`Thumbnail ${i + 1}`}
                      className="h-full w-full object-cover"
                      onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/80x80?text=No+Image")}
                    />
                  </button>
                ))}
              </div>
            )}
          </section>

          {/* Details */}
          <section>
            {/* Category + brand */}
            <div className="mb-3 flex flex-wrap items-center gap-2 text-sm text-gray-600">
              <Pill>{product.category}</Pill>
              {product.brand && <span>• {product.brand}</span>}
            </div>

            <h1 className="mb-2 text-2xl font-bold text-gray-900 sm:text-3xl">{product.name}</h1>

            {/* Rating */}
            <div className="mb-4 flex items-center gap-2">
              <div className="flex">{sr(product.rating || 0)}</div>
              <span className="text-sm text-gray-500">
                {product.rating || 0} ({product.numReviews || 0} reviews)
              </span>
            </div>

            {/* Price */}
            <div className="mb-4 flex items-end gap-3">
              <span className="text-3xl font-extrabold tracking-tight text-gray-900">${product.price}</span>
              {product.originalPrice && product.originalPrice > product.price && (
                <>
                  <span className="text-lg text-gray-500 line-through">${product.originalPrice}</span>
                  <Pill tone="save">Save ${(product.originalPrice - product.price).toFixed(2)}</Pill>
                </>
              )}
            </div>

            {/* Stock */}
            <div
              className={`mb-4 flex items-center gap-2 rounded-lg border px-3 py-2 text-sm ${
                product.quantity > 0
                  ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                  : "border-rose-200 bg-rose-50 text-rose-700"
              }`}
            >
              {product.quantity > 0 ? (
                <>
                  <svg viewBox="0 0 24 24" className="h-4 w-4"><path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
                  In Stock ({product.quantity} available)
                </>
              ) : (
                <>Out of Stock</>
              )}
            </div>

            {/* Description (short) */}
            {product.description && (
              <p className="mb-6 leading-relaxed text-gray-600">{product.description}</p>
            )}

            {/* Available Colors */}
            {product.colors && product.colors.length > 0 && (
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-700">Available Colors:</span>
                <div className="flex gap-2 mt-2">
                  {product.colors.map((color, index) => (
                    <div
                      key={index}
                      className="w-8 h-8 rounded-full border-2 border-gray-200"
                      style={{ backgroundColor: color.code }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Available Sizes */}
            {product.sizes && product.sizes.length > 0 && (
              <div className="mb-4">
                <span className="text-sm font-medium text-gray-700">Available Sizes:</span>
                <div className="flex gap-2 mt-2">
                  {product.sizes.map((size, index) => (
                    <span
                      key={index}
                      className={`px-3 py-1 rounded text-sm border ${
                        size.available
                          ? 'border-gray-300 bg-white text-gray-700'
                          : 'border-gray-200 bg-gray-100 text-gray-400'
                      }`}
                    >
                      {size.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Qty */}
            {product.quantity > 0 && (
              <div className="mb-6 flex items-center gap-3">
                <span className="text-sm font-medium text-gray-700">Quantity:</span>
                <div className="inline-flex items-center overflow-hidden rounded-lg border">
                  <button
                    className="h-10 w-10 hover:bg-gray-50 disabled:opacity-40"
                    onClick={() => setQty(Math.max(1, qty - 1))}
                    disabled={qty <= 1}
                    aria-label="Decrease quantity"
                  >
                    −
                  </button>
                  <div className="min-w-[56px] py-2 text-center font-semibold">{qty}</div>
                  <button
                    className="h-10 w-10 hover:bg-gray-50 disabled:opacity-40"
                    onClick={() => setQty(Math.min(product.quantity, qty + 1))}
                    disabled={qty >= product.quantity}
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <button
                onClick={handleAddToCart}
                disabled={product.quantity <= 0 || product.isSold}
                className="inline-flex h-12 items-center justify-center rounded-xl bg-gray-900 text-white shadow-soft transition hover:translate-y-[-1px] hover:shadow-lg disabled:opacity-50"
              >
                <svg viewBox="0 0 24 24" className="mr-2 h-5 w-5"><path d="M3 3h2l.4 2M7 13h10l3-8H6.4M7 13L5.4 5M7 13l-2 9m12-9l2 9M9 22a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
                {(product.colors && product.colors.length > 0) || (product.sizes && product.sizes.length > 0) 
                  ? "Select Options" 
                  : "Add to Cart"
                }
              </button>
              <button
                onClick={toggleWishlist}
                className={`inline-flex h-12 items-center justify-center rounded-xl border bg-white shadow-sm transition hover:translate-y-[-1px] hover:shadow ${
                  isInWishlist(product._id)
                    ? "border-rose-300 text-rose-600"
                    : "border-gray-200 text-gray-800"
                }`}
              >
                {isInWishlist(product._id) ? "In Wishlist" : "Add to Wishlist"}
              </button>
              <button
                onClick={buyNow}
                disabled={product.quantity <= 0 || product.isSold}
                className="sm:col-span-2 inline-flex h-12 items-center justify-center rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-soft transition hover:translate-y-[-1px] hover:shadow-lg disabled:opacity-50"
              >
                {product.isSold ? "Sold Out" : "Buy Now"}
              </button>
            </div>

            {/* Trust badges */}
            <div className="mb-8 rounded-2xl border border-gray-200 bg-white p-4">
              <h3 className="mb-3 flex items-center gap-2 text-base font-semibold">
                <svg viewBox="0 0 24 24" className="h-5 w-5 text-gray-900"><path d="M12 2l7 4v6c0 5-3.5 9-7 10-3.5-1-7-5-7-10V6l7-4z" fill="currentColor"/></svg>
                Why choose this product?
              </h3>
              <ul className="grid grid-cols-2 gap-3 text-sm text-gray-700 sm:grid-cols-4">
                {["Free Shipping", "30-Day Returns", "2-Year Warranty", "Authentic Product"].map((t) => (
                  <li key={t} className="flex items-center gap-2 rounded-lg bg-gray-50 px-2 py-1">
                    <svg viewBox="0 0 24 24" className="h-4 w-4 text-emerald-600"><path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
                    {t}
                  </li>
                ))}
              </ul>
            </div>

            {/* Tabs */}
            <div className="rounded-2xl border border-gray-200 bg-white">
              <div className="flex gap-4 border-b px-4">
                <TabButton active={tab === 0} onClick={() => setTab(0)}>Description</TabButton>
                <TabButton active={tab === 1} onClick={() => setTab(1)}>Specifications</TabButton>
                <TabButton active={tab === 2} onClick={() => setTab(2)}>Features</TabButton>
                <TabButton active={tab === 3} onClick={() => setTab(3)}>Reviews</TabButton>
              </div>

              <div className="px-4 py-4">
                {tab === 0 && (
                  <div className="prose max-w-none prose-p:leading-relaxed">
                    {product.longDescription ? (
                      <>
                        <h4 className="mb-2 text-lg font-semibold">{product.description}</h4>
                        <p className="text-gray-600">{product.longDescription}</p>
                      </>
                    ) : (
                      <p className="text-gray-600">{product.description || "No detailed description available."}</p>
                    )}
                  </div>
                )}

                {tab === 1 && (
                  <>
                    {product.specifications && Object.keys(product.specifications).length > 0 ? (
                      <dl className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        {Object.entries(product.specifications).map(([k, v]) => (
                          <div key={k} className="rounded-xl bg-gray-50 p-3">
                            <dt className="text-sm font-medium text-gray-700">{k}</dt>
                            <dd className="text-sm font-semibold text-gray-900">{v}</dd>
                          </div>
                        ))}
                      </dl>
                    ) : (
                      <p className="py-6 text-center text-gray-500">No specifications available.</p>
                    )}
                  </>
                )}

                {tab === 2 && (
                  <>
                    {product.features?.length ? (
                      <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        {product.features.map((f, i) => (
                          <li key={i} className="flex items-center gap-2 rounded-xl bg-emerald-50 p-3 text-emerald-900">
                            <svg viewBox="0 0 24 24" className="h-4 w-4"><path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
                            {f}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="py-6 text-center text-gray-500">No features listed.</p>
                    )}
                  </>
                )}

                {tab === 3 && (
                  <div className="py-6 text-center">
                    <div className="mx-auto mb-3 h-14 w-14 rounded-full bg-gray-100" />
                    <h4 className="mb-1 text-lg font-semibold">
                      {product.numReviews > 0 ? `${product.numReviews} Reviews` : "No reviews yet"}
                    </h4>
                    <p className="mb-4 text-gray-500">
                      {product.numReviews > 0 ? "Review system coming soon!" : "Be the first to review this product!"}
                    </p>
                    <button
                      onClick={() => showToast("Review feature coming soon!", "info")}
                      className="inline-flex h-11 items-center justify-center rounded-xl border border-gray-200 bg-white px-6 font-medium shadow-sm transition hover:translate-y-[-1px] hover:shadow"
                    >
                      Write a Review
                    </button>
                  </div>
                )}
              </div>
            </div>
          </section>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <section className="mt-12">
            <h2 className="mb-4 text-2xl font-bold">Related Products</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-4">
              {related.map((p) => (
                <button
                  key={p._id}
                  onClick={() => navigate(`/product/${p._id}`)}
                  className="overflow-hidden rounded-2xl border border-gray-200 bg-white text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
                >
                  {/* eslint-disable-next-line jsx-a11y/img-redundant-alt */}
                  <img
                    src={p.images?.[0] || "https://via.placeholder.com/400x400?text=No+Image"}
                    alt={`${p.name} image`}
                    className="h-48 w-full object-cover"
                    onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/400x400?text=No+Image")}
                  />
                  <div className="p-3">
                    <div className="mb-1 line-clamp-1 font-semibold">{p.name}</div>
                    <div className="mb-1 flex items-center gap-1">
                      <div className="flex">{sr(p.rating || 0)}</div>
                      <span className="text-xs text-gray-500">({p.numReviews || 0})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold">${p.price}</span>
                      {p.originalPrice && p.originalPrice > p.price && (
                        <span className="text-sm text-gray-500 line-through">${p.originalPrice}</span>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Toast */}
      {toast && (
        <div
          className={`fixed inset-x-0 bottom-4 z-50 mx-auto w-fit rounded-xl px-4 py-2 text-sm shadow-lg ${
            toast.tone === "error"
              ? "bg-rose-600 text-white"
              : toast.tone === "success"
              ? "bg-emerald-600 text-white"
              : "bg-gray-900 text-white"
          }`}
        >
          {toast.msg}
        </div>
      )}

      {/* Size Color Modal */}
              <SizeColorModal
          isOpen={showSizeColorModal}
          onClose={() => setShowSizeColorModal(false)}
          onConfirm={handleModalConfirm}
          product={product}
          quantity={qty}
          actionType={modalAction}
        />
    </div>
  );
}

/* Utility button classes (Tailwind @apply; optional)
   You can move these to index.css if you like. */
