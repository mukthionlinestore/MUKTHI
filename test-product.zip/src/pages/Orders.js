import React from 'react';
import UserOrders from './UserOrders';

const Orders = () => {
  return <UserOrders />;
};

export default Orders;
