import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { FaEnvelope, FaLock, FaEye, FaEyeSlash } from "react-icons/fa";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

/**
 * Mobile-first, modern Tailwind UI with robust validations using Zod.
 * - Focused on small screens (≤ 400px wide) with fluid scaling up
 * - Accessible labels, aria-live regions, and keyboard-friendly controls
 * - Strong password rules & helpful inline messages
 */

const passwordRules =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\/?`~]).{8,}$/;

const LoginSchema = z.object({
  email: z
    .string({ required_error: "Email is required" })
    .min(1, "Email is required")
    .email("Please enter a valid email address"),
  password: z
    .string({ required_error: "Password is required" })
    .min(8, "Use at least 8 characters")
    .regex(
      passwordRules,
      "Must include upper & lower case, a number, and a symbol"
    ),
  remember: z.boolean().optional(),
});

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/";
  const { login, error: authError } = useAuth();

  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
  } = useForm({
    resolver: zodResolver(LoginSchema),
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: { email: "", password: "", remember: false },
  });

  const onSubmit = async (values) => {
    const result = await login({ email: values.email, password: values.password });
    if (result?.success) {
      navigate(from, { replace: true });
    } else if (result?.message) {
      setError("root", { type: "server", message: result.message });
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100">
      <div className="mx-auto flex min-h-screen max-w-md flex-col px-4">
        {/* Header / Brand */}
        <div className="flex items-center gap-3 pt-10 sm:pt-12">
          <div className="h-10 w-10 shrink-0 rounded-2xl bg-indigo-500/20 ring-1 ring-indigo-400/40" />
          <div>
            <p className="text-xs uppercase tracking-widest text-indigo-300/80">Welcome</p>
            <h1 className="text-xl font-semibold leading-tight sm:text-2xl">Sign in to continue</h1>
          </div>
        </div>

        {/* Card */}
        <div className="mt-6 rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur sm:mt-8 sm:p-6 shadow-[0_8px_40px_-12px_rgba(0,0,0,0.6)]">
          {/* Global error */}
          {(authError || errors.root?.message) && (
            <div
              className="mb-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-200"
              role="alert"
              aria-live="polite"
            >
              {errors.root?.message || authError}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid gap-4 sm:gap-5">
            {/* Email */}
            <div className="grid gap-2">
              <label htmlFor="email" className="text-sm font-medium text-slate-200">
                Email address
              </label>
              <div className="group relative">
                <FaEnvelope className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 opacity-60" />
                <input
                  id="email"
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  className={[
                    "w-full rounded-2xl border bg-slate-900/60 px-10 py-3 text-[15px] outline-none transition",
                    "placeholder:text-slate-500",
                    errors.email
                      ? "border-rose-500/50 focus:ring-2 focus:ring-rose-500/40"
                      : "border-white/10 focus:ring-2 focus:ring-indigo-500/40",
                  ].join(" ")}
                  {...register("email")}
                  aria-invalid={!!errors.email}
                  aria-describedby={errors.email ? "email-error" : undefined}
                />
              </div>
              {errors.email && (
                <p id="email-error" className="text-xs text-rose-300" aria-live="polite">
                  {errors.email.message}
                </p>
              )}
            </div>

            {/* Password */}
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="text-sm font-medium text-slate-200">
                  Password
                </label>
                <Link to="/forgot-password" className="text-xs text-indigo-300 hover:text-indigo-200">
                  Forgot?
                </Link>
              </div>
              <div className="group relative">
                <FaLock className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 opacity-60" />
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  className={[
                    "w-full rounded-2xl border bg-slate-900/60 px-10 py-3 text-[15px] outline-none transition",
                    "placeholder:text-slate-500",
                    errors.password
                      ? "border-rose-500/50 focus:ring-2 focus:ring-rose-500/40"
                      : "border-white/10 focus:ring-2 focus:ring-indigo-500/40",
                  ].join(" ")}
                  {...register("password")}
                  aria-invalid={!!errors.password}
                  aria-describedby={errors.password ? "password-error" : undefined}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-xl p-2 text-slate-400 hover:bg-white/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500/50"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>
              {/* {errors.password && (
                <p id="password-error" className="text-xs text-rose-300" aria-live="polite">
                  {errors.password.message}
                </p>
              )} */}

              {/* Password helper bullets on initial invalid */}
              {/* {!errors.password && (
                <ul className="mt-1 list-disc space-y-0.5 pl-5 text-[11px] text-slate-400">
                  <li>At least 8 characters</li>
                  <li>Upper & lower case</li>
                  <li>One number & one symbol</li>
                </ul>
              )} */}
            </div>

            {/* Remember me */}
            <label className="inline-flex items-center gap-3 text-sm text-slate-300">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-white/20 bg-slate-900/60 text-indigo-500 focus:ring-indigo-400/40"
                {...register("remember")}
              />
              Remember me
            </label>

            {/* Submit */}
            <button
              type="submit"
              disabled={isSubmitting}
              className={[
                "mt-2 inline-flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold",
                "bg-gradient-to-tr from-indigo-500 to-violet-500 text-white shadow-lg shadow-indigo-900/30",
                "transition active:scale-[.99] disabled:cursor-not-allowed disabled:opacity-60",
              ].join(" ")}
            >
              {isSubmitting ? (
                <span className="inline-flex items-center gap-2">
                  <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                  </svg>
                  Signing in…
                </span>
              ) : (
                "Sign in"
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="my-5 flex items-center gap-3 text-xs text-slate-400">
            <div className="h-px flex-1 bg-white/10" />
            <span>New here?</span>
            <div className="h-px flex-1 bg-white/10" />
          </div>

          {/* Footer */}
          <p className="text-center text-sm text-slate-300">
            Don't have an account?{" "}
            <Link to="/register" className="font-semibold text-indigo-300 hover:text-indigo-200">
              Sign up
            </Link>
          </p>
        </div>

        {/* Tiny footer note */}
        <div className="py-8 text-center text-[11px] text-slate-500">
          Protected by industry‑standard security. Please don’t share your password.
        </div>
      </div>
    </div>
  );
}



