import React, { useState, useEffect } from 'react';
import { useParams, useLocation, Link } from 'react-router-dom';
import axios from '../config/axios';
import { useAuth } from '../context/AuthContext';
import { 
  FaCheckCircle, 
  FaArrowLeft, 
  FaDownload, 
  FaShippingFast, 
  FaMapMarkerAlt, 
  FaCreditCard,
  FaCalendarAlt,
  FaBox,
  FaTruck,
  FaClock,
  FaExclamationTriangle,
  FaStar,
  FaPhone,
  FaEnvelope
} from 'react-icons/fa';
import { toast } from 'react-toastify';

const OrderDetail = () => {
  const { id } = useParams();
  const location = useLocation();
  const { isAuthenticated } = useAuth();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const isNewOrder = location.state?.newOrder;

  useEffect(() => {
    if (isAuthenticated && id) {
      fetchOrder();
    }
  }, [id, isAuthenticated]);

  const fetchOrder = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`/api/orders/${id}`);
      setOrder(response.data);
    } catch (error) {
      console.error('Error fetching order:', error);
      if (error.response?.status === 404) {
        toast.error('Order not found');
      } else if (error.response?.status === 403) {
        toast.error('You do not have permission to view this order');
      } else {
        toast.error('Failed to load order details');
      }
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'processing': return 'text-blue-600 bg-blue-100';
      case 'shipped': return 'text-purple-600 bg-purple-100';
      case 'delivered': return 'text-green-600 bg-green-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      case 'returned': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending': return <FaClock />;
      case 'processing': return <FaBox />;
      case 'shipped': return <FaTruck />;
      case 'delivered': return <FaCheckCircle />;
      case 'cancelled': return <FaExclamationTriangle />;
      case 'returned': return <FaExclamationTriangle />;
      default: return <FaClock />;
    }
  };

  const downloadInvoice = () => {
    // This would generate and download PDF invoice
    toast.info('Invoice download feature coming soon');
  };

  const trackOrder = () => {
    // This would open tracking page
    if (order.trackingNumber) {
      toast.info(`Tracking number: ${order.trackingNumber}`);
    } else {
      toast.info('Tracking information will be available once your order is shipped');
    }
  };

  const contactSupport = () => {
    // This would open support ticket or contact form
    toast.info('Redirecting to customer support...');
  };

  const requestReturn = () => {
    // This would open return request form
    if (order.status === 'delivered') {
      toast.info('Return request feature coming soon');
    } else {
      toast.warning('Returns can only be requested after delivery');
    }
  };

  const leaveReview = () => {
    // This would open review form
    if (order.status === 'delivered') {
      toast.info('Review feature coming soon');
    } else {
      toast.warning('Reviews can only be left after delivery');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="text-center bg-white rounded-xl shadow-sm p-8 max-w-md">
          <h2 className="text-xl font-semibold mb-4">Please log in</h2>
          <p className="text-gray-600 mb-6">You need to be logged in to view order details</p>
          <Link to="/login" className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
            Log In
          </Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading order details...</p>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="text-center bg-white rounded-xl shadow-sm p-8 max-w-md">
          <FaExclamationTriangle className="text-4xl text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-4">Order Not Found</h2>
          <p className="text-gray-600 mb-6">The order you're looking for doesn't exist or you don't have permission to view it.</p>
          <Link to="/orders" className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
            View All Orders
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Success Message for New Orders */}
        {isNewOrder && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0">
                <FaCheckCircle className="text-3xl text-green-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-green-800">Order Placed Successfully!</h3>
                <p className="text-green-700">Thank you for your purchase. Your order has been received and is being processed.</p>
              </div>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
            <div className="flex items-center gap-4">
              <Link 
                to="/orders" 
                className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <FaArrowLeft /> Back to Orders
              </Link>
            </div>
            <div className="flex gap-3 flex-wrap">
              <button
                onClick={trackOrder}
                className="flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
              >
                <FaTruck /> Track Order
              </button>
              <button
                onClick={downloadInvoice}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <FaDownload /> Invoice
              </button>
              {order.status === 'delivered' && (
                <>
                  <button
                    onClick={leaveReview}
                    className="flex items-center gap-2 px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors"
                  >
                    <FaStar /> Leave Review
                  </button>
                  <button
                    onClick={requestReturn}
                    className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                  >
                    <FaExclamationTriangle /> Request Return
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Order #{order.orderNumber}</h1>
              <p className="text-gray-600">
                Placed on {new Date(order.createdAt).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                {getStatusIcon(order.status)}
                {order.status}
              </span>
            </div>

            <div>
              <p className="text-sm text-gray-500">Total Amount</p>
              <p className="text-xl font-bold text-gray-900">${order.total.toFixed(2)}</p>
            </div>

            <div>
              <p className="text-sm text-gray-500">Payment Status</p>
              <p className={`font-medium ${order.isPaid ? 'text-green-600' : 'text-red-600'}`}>
                {order.isPaid ? 'Paid' : 'Pending'}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Order Items */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="p-6 border-b">
              <h2 className="text-xl font-semibold">Order Items</h2>
            </div>
            
            <div className="divide-y">
              {order.items.map((item, index) => (
                <div key={index} className="p-6 flex gap-4">
                  <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.product?.images?.[0] || '/placeholder-image.jpg'}
                      alt={item.product?.name || 'Product'}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-gray-900 truncate">
                      {item.product?.name || 'Product not available'}
                    </h3>
                    
                    {item.product?.brand && (
                      <p className="text-sm text-gray-500">{item.product.brand}</p>
                    )}
                    
                    <div className="mt-2 flex flex-wrap gap-4 text-sm text-gray-600">
                      {item.selectedColor && (
                        <div className="flex items-center gap-2">
                          <span>Color:</span>
                          <div
                            className="w-4 h-4 rounded-full border"
                            style={{ backgroundColor: item.selectedColor.code }}
                          />
                          <span>{item.selectedColor.name}</span>
                        </div>
                      )}
                      
                      {item.selectedSize && (
                        <span>Size: {item.selectedSize}</span>
                      )}
                      
                      <span>Qty: {item.quantity}</span>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Unit Price</p>
                    <p className="font-medium">${item.price.toFixed(2)}</p>
                    <p className="text-sm text-gray-500 mt-1">Total</p>
                    <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Total */}
            <div className="p-6 border-t bg-gray-50">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>${order.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Shipping</span>
                  <span>{order.shippingCost === 0 ? 'Free' : `$${order.shippingCost.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Tax</span>
                  <span>${order.tax.toFixed(2)}</span>
                </div>
                {order.discount && order.discount > 0 && (
                  <div className="flex justify-between text-sm text-green-600">
                    <span>Discount</span>
                    <span>-${order.discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg pt-2 border-t">
                  <span>Total</span>
                  <span>${order.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Order Information */}
          <div className="space-y-6">
            {/* Shipping Address */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center gap-3 mb-4">
                <FaMapMarkerAlt className="text-blue-600" />
                <h3 className="font-semibold">Shipping Address</h3>
              </div>
              
              <div className="space-y-1 text-sm">
                <p className="font-medium">{order.shippingAddress.fullName}</p>
                <p>{order.shippingAddress.street}</p>
                <p>
                  {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}
                </p>
                <p>{order.shippingAddress.country}</p>
                {order.shippingAddress.phone && (
                  <div className="flex items-center gap-2 mt-2">
                    <FaPhone className="text-xs" />
                    <span>{order.shippingAddress.phone}</span>
                  </div>
                )}
                {order.shippingAddress.email && (
                  <div className="flex items-center gap-2">
                    <FaEnvelope className="text-xs" />
                    <span>{order.shippingAddress.email}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Payment Information */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center gap-3 mb-4">
                <FaCreditCard className="text-green-600" />
                <h3 className="font-semibold">Payment Information</h3>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Method:</span>
                  <span className="font-medium">{order.paymentMethod}</span>
                </div>
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className={`font-medium ${order.isPaid ? 'text-green-600' : 'text-red-600'}`}>
                    {order.isPaid ? 'Paid' : 'Pending'}
                  </span>
                </div>
                {order.isPaid && order.paidAt && (
                  <div className="flex justify-between">
                    <span>Paid on:</span>
                    <span>{new Date(order.paidAt).toLocaleDateString()}</span>
                  </div>
                )}
                {order.transactionId && (
                  <div className="flex justify-between">
                    <span>Transaction ID:</span>
                    <span className="font-mono text-xs">{order.transactionId}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Delivery Information */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center gap-3 mb-4">
                <FaShippingFast className="text-purple-600" />
                <h3 className="font-semibold">Delivery Information</h3>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className="font-medium">{order.status}</span>
                </div>
                
                {order.trackingNumber && (
                  <div className="flex justify-between">
                    <span>Tracking:</span>
                    <span className="font-medium text-blue-600">{order.trackingNumber}</span>
                  </div>
                )}
                
                {order.shippingMethod && (
                  <div className="flex justify-between">
                    <span>Method:</span>
                    <span className="font-medium">{order.shippingMethod}</span>
                  </div>
                )}
                
                {order.isDelivered && order.deliveredAt && (
                  <div className="flex justify-between">
                    <span>Delivered:</span>
                    <span className="font-medium text-green-600">
                      {new Date(order.deliveredAt).toLocaleDateString()}
                    </span>
                  </div>
                )}

                {!order.isDelivered && order.status !== 'cancelled' && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                    <p className="text-blue-700 text-xs">
                      Estimated delivery: 3-5 business days from order date
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Order Timeline */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center gap-3 mb-4">
                <FaCalendarAlt className="text-gray-600" />
                <h3 className="font-semibold">Order Timeline</h3>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="text-sm">
                    <span className="font-medium">Order Placed</span>
                    <p className="text-gray-500">{new Date(order.createdAt).toLocaleString()}</p>
                  </div>
                </div>
                
                {order.status !== 'pending' && (
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="text-sm">
                      <span className="font-medium">Processing</span>
                      <p className="text-gray-500">Order confirmed and being prepared</p>
                    </div>
                  </div>
                )}
                
                {(order.status === 'shipped' || order.status === 'delivered') && (
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="text-sm">
                      <span className="font-medium">Shipped</span>
                      <p className="text-gray-500">Order is on its way</p>
                    </div>
                  </div>
                )}
                
                {order.isDelivered && (
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="text-sm">
                      <span className="font-medium">Delivered</span>
                      <p className="text-gray-500">{new Date(order.deliveredAt).toLocaleString()}</p>
                    </div>
                  </div>
                )}

                {order.status === 'cancelled' && (
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="text-sm">
                      <span className="font-medium">Cancelled</span>
                      <p className="text-gray-500">Order was cancelled</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Customer Support */}
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="font-semibold mb-3">Need Help?</h3>
              <div className="space-y-2 text-sm">
                <p>If you have any questions about your order, please contact our customer support team.</p>
                <div className="flex items-center gap-2 text-blue-600 cursor-pointer hover:text-blue-700">
                  <FaPhone className="text-xs" />
                  <span>1-800-123-4567</span>
                </div>
                <div className="flex items-center gap-2 text-blue-600 cursor-pointer hover:text-blue-700">
                  <FaEnvelope className="text-xs" />
                  <span>support@example.com</span>
                </div>
                <button
                  onClick={contactSupport}
                  className="w-full mt-3 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Contact Support
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetail;